
   <?php
   
   
    include_once("converte.class.php");
    include_once("conn.class.php");
    include_once("config.php");

    $obj_connect = new Conexao($db,$host,$port,$user,$password);  
    $obj_connectw = new Conexao($wdb,$whost,$wport,$wuser,$wpassword);

    $connw = $obj_connectw -> getConnection();

    //pega a query
    $resw = $connw -> query("select query from conversao where cod_id = 852");

    while ($linhaw = $resw -> fetch(PDO::FETCH_ASSOC)){ 

        $query = $linhaw["query"];

    }    

   

    $conn = $obj_connect -> getConnection();
    
    echo($query);

   $res = $conn -> query("$query");
  


   

    
    
    while ($linha = $res -> fetch(PDO::FETCH_ASSOC)){ 


        echo($linha["valor"]);           
      
    

    }    







?>