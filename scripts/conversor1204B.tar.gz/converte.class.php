<?php

set_time_limit(0);
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);

include_once("conn.class.php");


   
class Converte{

    
    private $tabela_origem; 
    private $campos_origem;
    private $prefixo;
    private $linha_a_linha;
    
    //destino (web)
    private $db;
    private $host;
    private $port;
    private $user;
    private $password;

    //origem
    private $odb;
    private $ohost;
    private $oport;
    private $ouser;
    private $opassword;

    private $conexao_origem;
    private $conexao_destino;


    
    function __construct($db,$host,$port,$user,$password,$odb,$ohost,$oport,$ouser,$opassword){

            $this -> db = $db;
            $this -> host = $host;
            $this -> port = $port;
            $this -> user = $user;
            $this -> password = $password;

            $this -> odb = $odb;
            $this -> ohost = $ohost;
            $this -> oport = $oport;
            $this -> ouser = $ouser;
            $this -> opassword = $opassword;

            //configura a conexão de destino

            $obj_conexao_destino = new Conexao($db,$host,$port,$user,$password);

            $conn_destino = $obj_conexao_destino -> getConnection();

            $this -> conexao_destino = $conn_destino;

            //configura a conexao de origem

            $obj_conexao_origem = new Conexao($odb,$ohost,$oport,$ouser,$opassword);

            $conn_origem = $obj_conexao_origem -> getConnection();

            $this -> conexao_origem = $conn_origem;


    }

   

    public function __set($propriedade,$valor){

        $this -> $propriedade = $valor;

    }


    public function __get($propriedade){

        return $this -> $propriedade;

    }


    private $campo_origem; 
    private $tabela_destino; 
    private $campo_destino; 
    private $converter_string; 


    private function total_registros($tabela){

        $db = $this -> odb;
        $host = $this -> ohost;
        $port = $this -> oport;
        $user = $this -> ouser;
        $password = $this -> opassword;

        $campo_id =  $this -> id_origem($tabela);       
 
        $conn = $this -> conexao_origem;
 
        $query = "select count($campo_id) as tot from $tabela";

        $res = $conn -> query($query);
        
        while ($linha = $res -> fetch(PDO::FETCH_BOTH)){

          $total = $linha["tot"];

        }    
 

        return $total;

    }


    private function prefixo($tabela){ 

        echo("<br><font>Preparando inserção da tabela $tabela</font>");

        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;

        $this -> tabela_destino = $tabela;

         //prepara a primeira parte da inserção dos dados
         $prefixo = "insert into $tabela ";

         //faz a consulta de todos os campos daquela tabela
 
        $conn = $this -> conexao_destino;
 
        $query = "select campo_destino,tabela_origem,campo_origem from conversao where tabela_destino =\"$tabela\"";

        $res = $conn -> query($query);

        $prefixob = "(";

        $campos_origem = "";
 
        while ($linha = $res -> fetch(PDO::FETCH_BOTH)){
 
            $campo = $linha[0];

            $this -> tabela_origem = $linha[1];

            if ($campos_origem != ""){
                $campos_origem .=",";
            }

            $campos_origem .= $linha[2];
 
            $prefixob .= $campo.",";
 
        }

         $this -> campos_origem = $campos_origem;
 

         $prefixob .=")";
 
         $prefixob = str_replace(",)",")",$prefixob);
 
         $prefixob .= " values ";
 
         $this -> prefixo = "$prefixo $prefixob";

    }



    private function sufixo(){ //precisa ser chamado sempre logo após os prefixo, no mesmo objeto que chamou o prefixo

        $tabela_origem =  $this -> tabela_origem;

        $tot = $this -> total_registros($tabela_origem);

        echo("<br>Consultando todos os $tot registros da tabela $tabela_origem. Seja paciente...");

        
        
        ob_flush();
        sleep(1);
       
        
        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;

       

        $campos_origem =  $this -> campos_origem;

       
        
        $conn_destino = $this -> conexao_destino;

        $query = "select $campos_origem from $tabela_origem "; 

       // if ($tabela_origem != "nãoexisteestatabela"){ $query .= " limit 1000"; } ///////<----------------para testar apenas 1000 registros de cada tabela

        return $this -> dados($query);       

    }

    private function setPreparaOrigem(){
       
        $odb = $this -> odb;
        $ohost = $this -> ohost;
        $oport = $this -> oport;
        $ouser = $this -> ouser;
        $opassword = $this -> opassword;

        $db_destino = $this -> db;
        $host_destino = $this -> host;

        echo("<br>Base de origem: $odb em $ohost  Destino: $db_destino  em $host_destino ....");

        echo("<br>Preparando as tabelas de origem, apagando dados antigos e inativos....");

        //apaga na agenda vários campos, e nos animais e proprietários também

       

        $conn_origem = $this -> conexao_origem;

        $conn_origem -> query("delete from agenda where year(data) < 2018");

        //pega o menor id da agenda, para poder apagar nas outras tabelas que não tem data

        $res = $conn_origem -> query("select min(codid_agenda) as minimo from agenda");

        while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $minimo = $linha["minimo"];

        }

        echo("<br>Menor id da agenda: $minimo.... Apagando e ajustando registros:");

        $conn_origem -> query("delete from agenda where year(data) < 2018");
        $conn_origem -> query("delete from agenda where tipo='venda'");
        $conn_origem -> query("delete from agenda where status <= 0");
        $conn_origem -> query("delete from cadcli where status <= 0");
        $conn_origem -> query("delete from animal where status <= 0");

        
        
        $conn_origem -> query("delete from acconsultas where cod_agenda < $minimo");  
        $conn_origem -> query("delete from acinternacao where cod_agenda < $minimo"); 
        $conn_origem -> query("delete from rescirurgia where cod_agenda < $minimo"); 
        $conn_origem -> query("delete from resdiversos where cod_agenda < $minimo"); 
        $conn_origem -> query("delete from resestetica where cod_agenda < $minimo"); 
        $conn_origem -> query("delete from resexames where cod_agenda < $minimo"); 
        $conn_origem -> query("delete from resinternacao where cod_agenda < $minimo"); 
        $conn_origem -> query("delete from resvacina where cod_agenda < $minimo"); 


        $conn_origem -> query("alter table agenda change column descricao descricao text"); 
        $conn_origem -> query("update agenda set descricao=concat(descricao,' Conversão:',desc_interna2)"); 
        
    }


    private function setPreparaDestino(){


        echo("<br>Preparando as tabelas de destino, apagando dados antigos e inativos....");

        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;
        


        //apaga vários campos que possam estar na tabela de destino

       

        $conn_destino = $this -> conexao_destino;

        $conn_destino -> query("delete from agendas");        
        $conn_destino -> query("delete from proprietarios");
        $conn_destino -> query("delete from animais");
        $conn_destino -> query("delete from racas");
        $conn_destino -> query("delete from especies");
        $conn_destino -> query("delete from pelagens");
        $conn_destino -> query("delete from faturas");
        $conn_destino -> query("delete from pagamentos");

                     

    }






    private function id_origem($tabela_origem){

        $odb = $this -> odb;
        $ohost = $this -> ohost;
        $oport = $this -> oport;
        $ouser = $this -> ouser;
        $opassword = $this -> opassword;
        


        //pego o campo id da origem       

       

        $conn_origem = $this -> conexao_origem;

        $query_key = "show columns from $tabela_origem where `Key` = 'PRI'";

        $conn_origem -> query($query_key);
    
        $res_key = $conn_origem -> query($query_key);

        while ($linha_key = $res_key -> fetch(PDO::FETCH_BOTH)){
    
            $chave = $linha_key[0];   

        }

        return $chave;

    }


    private function tem_query($i,$valor_id){

            $db = $this -> db;
            $host = $this -> host;
            $port = $this -> port;
            $user = $this -> user;
            $password = $this -> password;

            //o de origem
            $odb = $this -> odb;
            $ohost = $this -> ohost;
            $oport = $this -> oport;
            $ouser = $this -> ouser;
            $opassword = $this -> opassword;

            $tabela_origem = $this -> tabela_origem;

            $valor = "";

             //verifica se é para mudar o valor por uma query
            

             $conn2 = $this -> conexao_destino;

             $query2 = "select query from conversao where tabela_origem = \"$tabela_origem\" limit $i,1";

             

             $res2 = $conn2 -> query($query2);

             while ($linha2 = $res2 -> fetch(PDO::FETCH_BOTH)){
             
                 $query_subs = $linha2["query"];   

             }     

             //se é para mudar o valor por uma query, coloca o campo valor (sempre vai ser valor) no lugar do original
             if ($query_subs != "" && strlen($query_subs) > 10 ){



                 $query_subs = str_replace("id_origem","$valor_id",$query_subs); //muda a string id_origem (caso exista) para o valor do id de origem 

                 

                 $conn_subs = $this -> conexao_origem;

                //echo($query_subs);

                 $res_subs = $conn_subs -> query($query_subs);

                 while ($linha_subs = $res_subs -> fetch(PDO::FETCH_BOTH)){
             
                     $valor = $linha_subs["valor"];   
 
                 }   
            

             }


            
             return $valor;




    }


    private function saida_usuario($texto,$perc){


          flush();
          sleep(0.01);

          echo("<script>
          
          window.parent.document.getElementById('status').innerText = \"$texto\";

          window.parent.document.getElementById('dv_progresso').style.width = \"$perc%\";           

          </script>");

          //fim da saída para o usuáio







    }




    private function dados($query){ //chamado pelo sufixo
        //o de origem
        $odb = $this -> odb;
        $ohost = $this -> ohost;
        $oport = $this -> oport;
        $ouser = $this -> ouser;
        $opassword = $this -> opassword;


        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;
       

       
        

        $conn_origem = $this -> conexao_origem;

        $dados = "";

        $res_origem = $conn_origem -> query($query); //geralmente select campo1,campo2 from tabela_origem, ou seja, vai pegar todos os dados que vieram lá do sufixo

        $ncolunas = $res_origem -> columnCount();

        $nregistros = $res_origem -> rowCount();

        $tabela_origem = $this -> tabela_origem;

        $tabela_destino = $this -> tabela_destino;

        $id_origem = $this -> id_origem($tabela_origem);

        $prefixo = $this -> prefixo ;

        $miolo = "";

        $cont = 0;

        while ($linha = $res_origem -> fetch(PDO::FETCH_BOTH)){

            $miolo_linha = "(";

            for ($i = 0; $i < $ncolunas;$i++){ 

                $valor = $linha[$i];    
                
                $valor_id = $linha["$id_origem"];

                 
                $valor_query = $this -> tem_query($i,$valor_id);

                if ($valor_query != ""){


                    $valor = $valor_query;

                   

                }


               




                $valor = str_replace('"',"'",$valor); 
                $valor = str_replace('0000-00-00','null',$valor);                 
                $valor = preg_replace( "/\r|\n/", "", $valor);
                $valor = str_replace('\\','',$valor);                 


                if ($valor != "null"){

                    $miolo_linha.= "\"" . $valor ."\",";

                }else{

                    $miolo_linha.= $valor.",";    

                }

            }


           

           
          //saída para o usuário, esta parte faz com que demore mais de 4 vezes mais
          $cont ++;

          $perc = $cont * 100 / $nregistros;

          $perc = round($perc,1);

          $texto = "$perc"."%";          

          $this -> saida_usuario($texto,$perc);



            $miolo_linha = str_replace("\"\"","null",$miolo_linha);                       


            $miolo_linha.="),\n";
            $miolo_linha = str_replace(",),","),",$miolo_linha);


            $linha_a_linha = $this -> __get("linha_a_linha");

            if ($linha_a_linha ==1){

                $miolo_linha = $prefixo . $miolo_linha; 
                $miolo .= $miolo_linha .";";

            }else{

                if ($cont == 1){

                    $miolo_linha = $prefixo . $miolo_linha; 

                }

                $miolo .= $miolo_linha;

            }

            
           

            

        }

        $miolo = $miolo . ";";

        $miolo = str_replace(",;",";",$miolo);
       
        $miolo = str_replace("),\n;",");\n",$miolo);

         

        $miolo =" delete from $tabela_destino;".$miolo;       
       
        $this -> file_add($miolo);
        

       

    }

    private function converToPlain($texto){
        $texto = preg_replace('"{\*?\\\\.+(;})|\\s?\\\[A-Za-z0-9]+|\\s?{\\s?\\\[A-Za-z0-9‹]+\\s?|\\s?}\\s?"', '', $texto);
        return $texto;
    }


    private function tiraRtf($texto){


        $texto = $this -> converToPlain($texto);

        $texto = mb_convert_encoding($texto,"utf-8","AUTO");       

        $texto = str_replace(" ","",$texto);

        return $texto;

    }



    private function file_add($texto){

        $texto = $this -> tiraRtf($texto);

        $odb = $this -> odb;

        $file_name = $odb.".sql";

        $arquivo = fopen($file_name,'a'); //a coloca o ponteiro no final, w no início, use a


        fwrite($arquivo,$texto);
        

        fclose($arquivo);

        $server = $_SERVER['SERVER_NAME'];
        
        $path = $_SERVER['SCRIPT_FILENAME'];
        $path_parts = pathinfo($path);

        $path_ex = str_replace("/",";",$path);

        $arr_path = explode(";",$path_ex);
    
        $folder = $arr_path[1];

        $server = $path_parts["dirname"];
        $path = "$server/$file_name";

        echo("Arquivo gerado com sucesso<br>");
        echo("Rode o seguinte comando mysql:<br>");
        echo("mysql -uNOMEDABASEDEDADOS -p -hmysql26-farm1.kinghost.net --binary-mode=1 --force --default-character-set=utf8 NOMEDABASEDEDADOS < $path");

    }


    private function converte_esteticas(){


        echo("Preparando a tabela ESTÉTICA... Aguarde");

        flush();
        sleep(0.01);


        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;

        //o de origem
        $odb = $this -> odb;
        $ohost = $this -> ohost;
        $oport = $this -> oport;
        $ouser = $this -> ouser;
        $opassword = $this -> opassword;


         //cria a conexão de destino   
         
        
         $conn_destino = $this -> conexao_destino;

       
         //se preocupa com a tabela de origem
         
         $conn_origem = $this -> conexao_origem;
  
        

         $conn_destino -> query ("delete from servicos"); //aqui apago todos, nos outros somente o específico

         $conn_destino -> query ("alter table servicos add column id_old int");
         
         $prefixo_servico = "insert into servicos (cod_id,nome,preco,tipo,id_old) values ";

         $cont = 0;

         $linha_a_linha = $this -> __get("linha_a_linha");

         //enaquanto tiver valores para passar da tabela estetica para a tabela servicos vai fazer

         $query = "select codid_estetica,nome,valpeqcurto from estetica where status>0";
  
         $res = $conn_origem -> query($query);  

          while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $cont++;

            $nome = $linha["nome"];

            $preco = $linha["valpeqcurto"];

            $id_antigo = $linha["codid_estetica"];

            //insere o valor na tabela servicos do infovet web

            $query = $prefixo_servico . " (null,\"$nome\",\"$preco\",\"Estética\",\"$id_antigo\")";

            $conn_destino -> query ($query);

            echo($query);

          }

          //agora que tem as esteticas inseridas na base web junto com os ids antigos ele pega na base de origem, o resesteticas e já muda os ids para quando for jogar no agendas_esteticas jogar correto

          $res = $conn_destino -> query ("select cod_id,id_old from servicos where tipo='Estética'");

          while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $id_novo = $linha["cod_id"];
            $id_antigo = $linha["id_old"];

            $conn_origem -> query("update resestetica set cod_estetica=$id_novo where cod_estetica=$id_antigo");

          }
          
          //agora a resesteticas tem o id correto, preciso jogar na agenda , tudo na origem - cuidado
       
         $query = "select cod_estetica,cod_agenda from resestetica where status>0";
  
         $res = $conn_origem -> query($query);

         while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $cod_estetica = $linha["cod_estetica"];
            $cod_agenda = $linha["cod_agenda"];

            $query ="update agenda set cod_servico=\"$cod_estetica\" where codid_agenda=\"$cod_agenda\"";            


            $conn_origem -> query($query);

          }

    }


   

    private function converte_exames(){


        echo("Preparando a tabela EXAMES... Aguarde");

        flush();
        sleep(0.01);


        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;

         //o de origem
         $odb = $this -> odb;
         $ohost = $this -> ohost;
         $oport = $this -> oport;
         $ouser = $this -> ouser;
         $opassword = $this -> opassword;

         //cria a conexão de destino   
                 
         $conn_destino = $this -> conexao_destino;     
        
         //insere o exame conversao
         $conn_destino -> query ("insert into servicos (cod_id,nome,preco,tipo) values (null,\"conversao\",\"0\",\"Exame\")");

         $id_exame = $conn_destino -> lastInsertId();

         //na tabela origem já muda todos os exames para o exame conversão     
         
         $conn_origem = $this -> conexao_origem;
  
         $query = "update agenda set cod_servico=\"$id_exame\" where tipo = \"Exame\"";

         $conn_origem -> query ($query);


    }     


    private function converte_diversos(){


        echo("Preparando a tabela DIVERSOS... Aguarde");

        flush();
        sleep(0.01);


        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;

        //o de origem
        $odb = $this -> odb;
        $ohost = $this -> ohost;
        $oport = $this -> oport;
        $ouser = $this -> ouser;
        $opassword = $this -> opassword;


         //cria a conexão de destino   
        
        
         $conn_destino = $this -> conexao_destino;

       
         //se preocupa com a tabela de origem
        

         $conn_origem = $this -> conexao_origem;
  
         $query = "select codid_procedimento,nome,valor from procedimentos where status>0";
  
         $res = $conn_origem -> query($query);

         $conn_destino -> query ("delete from servicos where tipo='Diversos'");

         $conn_destino -> query ("alter table servicos add column id_old int");      

         //enaquanto tiver valores para passar da tabela procedimentos para a tabela servicos vai fazer
          while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $nome = $linha["nome"];

            $preco = $linha["valor"];

            $id_antigo = $linha["codid_procedimento"];

            //insere o valor na tabela servicos do infovet web

            $query = "insert into servicos (cod_id,nome,preco,tipo,id_old) values (null,\"$nome\",\"$preco\",\"Diversos\",\"$id_antigo\")";

            $conn_destino -> query ($query);

          }

          //agora que tem os diversos inseridos na base web  (tabela servicos) junto com os ids antigos ele pega na base de origem, o resdiversos e já muda os ids para quando for jogar no agendas_esteticas jogar correto

          $res = $conn_destino -> query ("select cod_id,id_old from servicos where tipo='Diversos'");

          while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $id_novo = $linha["cod_id"];
            $id_antigo = $linha["id_old"];

            $conn_origem -> query("update resdiversos set cod_proc=$id_novo where cod_proc=$id_antigo");

          }
          
          //agora a resesteticas tem o id correto, preciso jogar na agenda , tudo na origem - cuidado
       
         $query = "select cod_proc,cod_agenda from resdiversos where status>0";
  
         $res = $conn_origem -> query($query);

         while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $cod_estetica = $linha["cod_proc"];
            $cod_agenda = $linha["cod_agenda"];

            $query ="update agenda set cod_servico=\"$cod_estetica\" where codid_agenda=\"$cod_agenda\"";            


            $conn_origem -> query($query);

          }

    }


    private function converte_cirurgia(){


        echo("<br>Preparando a tabela cirurgia... Aguarde");

        flush();
        sleep(0.01);


        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;

        //o de origem
        $odb = $this -> odb;
        $ohost = $this -> ohost;
        $oport = $this -> oport;
        $ouser = $this -> ouser;
        $opassword = $this -> opassword;


         //cria a conexão de destino          
        
         $conn_destino = $this -> conexao_destino;

         $conn_destino -> query ("delete from servicos where tipo='Cirurgia'");

         $conn_destino -> query ("alter table servicos add column id_old int");      

       
         //se preocupa com a tabela de origem        

         $conn_origem = $this -> conexao_origem;
  
         $query = "select codid_cirurgia,nome,valor from cirurgia where status>0";
  
         $res = $conn_origem -> query($query);
                 

         //enaquanto tiver valores para passar da tabela cirurgia para a tabela servicos vai fazer
          while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $nome = $linha["nome"];

            $preco = $linha["valor"];

            $id_antigo = $linha["codid_cirurgia"];

            //insere o valor na tabela servicos do infovet web

            $query = "insert into servicos (cod_id,nome,preco,tipo,id_old) values (null,\"$nome\",\"$preco\",\"Cirurgia\",\"$id_antigo\")";

            $conn_destino -> query ($query);

          }

          //agora que tem os cirurgias inseridos na base web  (tabela servicos) junto com os ids antigos ele corrige no rescirurgia o id das cirurgias pelos novos ids

          $res = $conn_destino -> query ("select cod_id,id_old from servicos where tipo='Cirurgia'");

          while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $id_novo = $linha["cod_id"];
            $id_antigo = $linha["id_old"];

            $conn_origem -> query("update rescirurgia set CODCIRUR=$id_novo where CODCIRUR=$id_antigo");

          }
          
          //agora a resesteticas tem o id correto, preciso jogar na agenda , tudo na origem - cuidado
       
         $query = "select CODCIRUR,cod_agenda from rescirurgia where status>0";
  
         $res = $conn_origem -> query($query);

         while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $cod_estetica = $linha["CODCIRUR"];
            $cod_agenda = $linha["cod_agenda"];

            $query ="update agenda set cod_servico=\"$cod_estetica\" where codid_agenda=\"$cod_agenda\"";            


            $conn_origem -> query($query);

          }

    }
    //vacina ok depois de rodar o depois.bck
    //


    private function SetTabelaServicos(){

        $db = $this -> db;
        $host = $this -> host;
        $port = $this -> port;
        $user = $this -> user;
        $password = $this -> password;

        //o de origem
        $odb = $this -> odb;
        $ohost = $this -> ohost;
        $oport = $this -> oport;
        $ouser = $this -> ouser;
        $opassword = $this -> opassword;
        
        
        $prefixo = "insert into servicos(cod_id,cod_fotos,cod_centros_custos,status,nome,preco,comissao,tipo,cod_valores) values ";

       

        $conn = $this -> conexao_destino;

        $res = $conn -> query("select * from servicos");

        $core = "";

        $all = "";

        $cont = 0;

        while ($linha = $res -> FETCH(PDO::FETCH_ASSOC)){

            $cont ++;

            $cod_id = $linha["cod_id"]; 
            $cod_fotos = $linha["cod_fotos"]; 
            $cod_centros_custos = $linha["cod_centros_custos"]; 
            $status = $linha["status"]; 
            $nome = $linha["nome"]; 
            $preco = $linha["preco"]; 
            $comissao = $linha["comissao"]; 
            $tipo = $linha["tipo"]; 
            $cod_valores = $linha["cod_valores"];

            $linha_a_linha = $this -> __get("linha_a_linha");

            if ($linha_a_linha == 1){

                $core = "(\"$cod_id\",\"$cod_fotos\",\"$cod_centros_custos\",\"$status\",\"$nome\",\"$preco\",\"$comissao\",\"$tipo\",\"$cod_valores\");";

                $core = str_replace('""',"null",$core);

                $all .= $prefixo . $core."\n";
                
            }else{

                $core = "(\"$cod_id\",\"$cod_fotos\",\"$cod_centros_custos\",\"$status\",\"$nome\",\"$preco\",\"$comissao\",\"$tipo\",\"$cod_valores\"),";

                $core = str_replace('""',"null",$core);

                if ($cont==1){

                    $all .= $prefixo . $core."\n";

                }else{

                    $all .= $core."\n";

                }

            }

        }

        $all .= ";";
        $all = str_replace(","."\n".";",";",$all);
        $all .="\n";

        $this -> file_add($all);

    }





    private function SetPreparaServicos(){

        $this -> file_add("delete from servicos;"); 
        $this -> converte_esteticas();
        $this -> converte_exames();
        $this -> converte_diversos();
        $this -> converte_cirurgia();



    }

    private function setPreparaUnidades(){

       
        //se preocupa com a tabela de origem       
 
        $conn_origem = $this -> conexao_origem;

        $db = $this -> odb;         


        
        $conn_origem -> query("alter table estoque change column data data varchar(15)");
        $conn_origem -> query("update estoque set data=null where data='0000-00-00'");
       

        $conn_origem -> query("alter table estoque change column unidade unidade varchar(30)");
        $conn_origem -> query("update estoque set unidade = '1' where unidade='unidade'");
        $conn_origem -> query("update estoque set unidade = '2' where unidade='GR'");
        $conn_origem -> query("update estoque set unidade = '3' where unidade='KG'");
        $conn_origem -> query("update estoque set unidade = '3' where unidade='Kilo'");
        $conn_origem -> query("update estoque set unidade = '4' where unidade='Litro'");
        $conn_origem -> query("update estoque set unidade = '5' where unidade='MT'");
        $conn_origem -> query("update estoque set unidade = '6' where unidade='CM'");
        $conn_origem -> query("update estoque set unidade = '7' where unidade='Comprimido'");
        $conn_origem -> query("update estoque set unidade = '8' where unidade='ML'");

        $conn_origem -> query("update estoque set embalagem = '1' where embalagem='Caixa'");
        $conn_origem -> query("update estoque set embalagem = '2' where embalagem='Lata'");
        $conn_origem -> query("update estoque set embalagem = '3' where embalagem='Blister'");
        $conn_origem -> query("update estoque set embalagem = '4' where embalagem='Fardo'");
        $conn_origem -> query("update estoque set embalagem = '5' where embalagem='Saco'");

        $conn_origem -> query("update estoque set embalagem = '7' where embalagem='Pote'");
        $conn_origem -> query("update estoque set embalagem = '8' where embalagem='Cartela'");
        $conn_origem -> query("update estoque set embalagem = '9' where embalagem='Ampola'");
        $conn_origem -> query("update estoque set embalagem = '10' where embalagem='Peça'");
        $conn_origem -> query("update estoque set embalagem = '11' where embalagem='Bisnaga'");
        $conn_origem -> query("update estoque set embalagem = '12' where embalagem='Envelope'");
        $conn_origem -> query("update estoque set embalagem = '13' where embalagem='Sachet'");
        $conn_origem -> query("update estoque set embalagem = '14' where embalagem='Frasco'");             
        
        $conn_origem -> query("alter table estoque change column etica etica varchar(30)");
        $conn_origem -> query("update estoque set etica = '0' where etica <> 'Sim'");
        $conn_origem -> query("update estoque set etica = '1' where etica='Sim'");

        $conn_origem -> query("alter table estoque change column data data date");


    }




    private function setPreparaPortes(){

        $conn_origem = $this -> conexao_origem;

        $query="

            alter table animal change column datacad datacad varchar(20);
            update animal set datacad=\"\" where datacad=\"0000-00-00\";            
            alter table animal change column porte porte varchar(20);
            update animal set porte=\"2\" where porte=\"Pequeno\";
            update animal set porte=\"3\" where porte=\"Médio\";
            update animal set porte=\"4\" where porte=\"Grande\";
            update animal set porte=\"5\" where porte=\"Gigante\";

        ";

        $conn_origem -> query($query);

    }    



    public function getPrefixo($tabela){


        return $this -> prefixo($tabela);
        

    }

    public function getSufixo(){


        return $this -> sufixo();
        

    }

    public function getDados(){


        return $this -> dados();


    }

    public function getPreparaOrigem(){

        $this -> setPreparaOrigem();

    }

    public function getPrepara(){

       
        $this -> setPreparaOrigem();
        $this -> setPreparaUnidades();
        $this -> setPreparaPortes();
        $this -> setPreparaServicos();
        $this -> setPreparaOrigem();
        $this -> setPreparaDestino();
        $this -> SetTabelaServicos();
        
        

    }














}    



?>