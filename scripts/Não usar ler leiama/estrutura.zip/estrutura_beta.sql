-- phpMyAdmin SQL Dump
-- version 4.3.7
-- http://www.phpmyadmin.net
--
-- Host: mysql26-farm1.kinghost.net
-- Tempo de geração: 19/01/2021 às 16:02
-- Versão do servidor: 10.2.31-MariaDB-log
-- Versão do PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `infovet`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `a1retornos`
--

CREATE TABLE IF NOT EXISTS `a1retornos` (
  `cod_id` int(11) NOT NULL,
  `retorno` text DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendamentos`
--

CREATE TABLE IF NOT EXISTS `agendamentos` (
  `cod_id` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `cod_animais` int(11) DEFAULT NULL,
  `cod_usuarios` int(11) DEFAULT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `grupo` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `tipo` varchar(25) DEFAULT NULL,
  `situacao` enum('Aguardando','Atendendo','Encaminhar','Encaminhado','Atendido','Futuro','Ignorou','Cancelou','Marcado','Retornou') DEFAULT NULL,
  `telebusca` varchar(25) DEFAULT NULL,
  `obs` varchar(150) DEFAULT NULL,
  `requisitante` int(11) DEFAULT NULL,
  `data_requisicao` date DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5036 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas`
--

CREATE TABLE IF NOT EXISTS `agendas` (
  `cod_id` int(11) NOT NULL,
  `cod_usuarios` int(11) DEFAULT NULL,
  `cod_proprietarios` int(11) DEFAULT NULL,
  `cod_animais` int(11) DEFAULT NULL,
  `cod_fornecedores` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `situacao` enum('Aguardando','Atendendo','Encaminhar','Encaminhado','Atendido','Futuro','Ignorou','Cancelou','Marcado','Retornou') DEFAULT NULL,
  `cod_servicos` int(11) DEFAULT NULL,
  `externo` enum('Sim','Não') DEFAULT 'Não',
  `avisado` varchar(10) DEFAULT 'Não',
  `retorno` varchar(4) DEFAULT NULL,
  `emergencia` enum('Sim','Não') DEFAULT 'Não',
  `grupo` int(11) DEFAULT NULL,
  `telebusca` enum('Não','Buscar','Levar','Buscar/Levar') DEFAULT NULL,
  `sessao` int(11) DEFAULT NULL,
  `quantidade` decimal(10,2) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `cod_faturas` int(11) DEFAULT 0,
  `fatura_comissao` int(11) DEFAULT 0,
  `obs` tinytext DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1598 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_cirurgias`
--

CREATE TABLE IF NOT EXISTS `agendas_cirurgias` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `aviso` text DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_consultas`
--

CREATE TABLE IF NOT EXISTS `agendas_consultas` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `cod_patologias` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `temperatura` decimal(10,2) DEFAULT NULL,
  `frequencia_cardiaca` decimal(10,2) DEFAULT NULL,
  `frequencia_respiratoria` decimal(10,2) DEFAULT NULL,
  `trc` decimal(10,2) DEFAULT NULL,
  `hidratacao` decimal(10,2) DEFAULT NULL,
  `peso` decimal(10,2) DEFAULT NULL,
  `terapeutica` text DEFAULT NULL,
  `anamnese` text DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_diversos`
--

CREATE TABLE IF NOT EXISTS `agendas_diversos` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `aviso` text DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_esteticas`
--

CREATE TABLE IF NOT EXISTS `agendas_esteticas` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `cod_pelos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `aviso` text DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=355 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_esteticas_comandas`
--

CREATE TABLE IF NOT EXISTS `agendas_esteticas_comandas` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_comandas_itens` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=189 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_bioquimicos`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_bioquimicos` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `acido_urico` decimal(10,2) DEFAULT NULL,
  `acidos_biliares` decimal(10,2) DEFAULT NULL,
  `acidos_biliares_jejum` decimal(10,2) DEFAULT NULL,
  `albumina` decimal(10,2) DEFAULT NULL,
  `amilase` decimal(10,2) DEFAULT NULL,
  `alt` decimal(10,2) DEFAULT NULL,
  `ast` decimal(10,2) DEFAULT NULL,
  `bilirrubina_direta` decimal(10,2) DEFAULT NULL,
  `bilirrubina_indireta` decimal(10,2) DEFAULT NULL,
  `bilirrubina_total` decimal(10,2) DEFAULT NULL,
  `calcio` decimal(10,2) DEFAULT NULL,
  `colesterol` decimal(10,2) DEFAULT NULL,
  `ck` decimal(10,2) DEFAULT NULL,
  `creatina` decimal(10,2) DEFAULT NULL,
  `digoxina` decimal(10,2) DEFAULT NULL,
  `fibrinogenio` decimal(10,2) DEFAULT NULL,
  `fosforo` decimal(10,2) DEFAULT NULL,
  `frutosamina` decimal(10,2) DEFAULT NULL,
  `ggt` decimal(10,2) DEFAULT NULL,
  `glicose` decimal(10,2) DEFAULT NULL,
  `globulina` decimal(10,2) DEFAULT NULL,
  `hemoglobina` decimal(10,2) DEFAULT NULL,
  `lipase` decimal(10,2) DEFAULT NULL,
  `fosfatase_alcalina` decimal(10,2) DEFAULT NULL,
  `fosfatase_alcalina_doze` decimal(10,2) DEFAULT NULL,
  `potassio` decimal(10,2) DEFAULT NULL,
  `proteina` decimal(10,2) DEFAULT NULL,
  `sodio` decimal(10,2) DEFAULT NULL,
  `ureia` decimal(10,2) DEFAULT NULL,
  `triglicerides` decimal(10,2) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_cavitarios`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_cavitarios` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `aspecto` varchar(30) DEFAULT NULL,
  `cor` varchar(30) DEFAULT NULL,
  `viscosidade` varchar(30) DEFAULT NULL,
  `coagulacao` varchar(30) DEFAULT NULL,
  `ph` varchar(30) DEFAULT NULL,
  `densidade` varchar(30) DEFAULT NULL,
  `proteinas` varchar(30) DEFAULT NULL,
  `glicose` varchar(30) DEFAULT NULL,
  `albumina` varchar(30) DEFAULT NULL,
  `ureia` varchar(30) DEFAULT NULL,
  `celulas_nucleadas_globais` varchar(30) DEFAULT NULL,
  `celulas_nucleadas_diferenciais` varchar(30) DEFAULT NULL,
  `ast` varchar(30) DEFAULT NULL,
  `conclusao` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_citologias`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_citologias` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `patologista` varchar(50) DEFAULT NULL,
  `material` varchar(30) DEFAULT NULL,
  `descricao` mediumtext DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `conclusao` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_dermatologicos`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_dermatologicos` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `papula` tinyint(4) DEFAULT 0,
  `vesicula` tinyint(4) DEFAULT 0,
  `acromia` tinyint(4) DEFAULT 0,
  `bolha` tinyint(4) DEFAULT 0,
  `calosidade` tinyint(4) DEFAULT 0,
  `eritema` tinyint(4) DEFAULT 0,
  `macula` tinyint(4) DEFAULT 0,
  `nodulo` tinyint(4) DEFAULT 0,
  `petequia` tinyint(4) DEFAULT 0,
  `purpura` tinyint(4) DEFAULT 0,
  `pustula` tinyint(4) DEFAULT 0,
  `tumor` tinyint(4) DEFAULT 0,
  `urticaria` tinyint(4) DEFAULT 0,
  `comedao` tinyint(4) DEFAULT 0,
  `colarete` tinyint(4) DEFAULT 0,
  `crosta` tinyint(4) DEFAULT 0,
  `descamacao` tinyint(4) DEFAULT 0,
  `edema` tinyint(4) DEFAULT 0,
  `escoriacao` tinyint(4) DEFAULT 0,
  `erosao` tinyint(4) DEFAULT 0,
  `fissura` tinyint(4) DEFAULT 0,
  `hiperpigmentacao` tinyint(4) DEFAULT 0,
  `liquenificacao` tinyint(4) DEFAULT 0,
  `necrose` tinyint(4) DEFAULT 0,
  `ulcera` tinyint(4) DEFAULT 0,
  `alopecia_localizada` tinyint(4) DEFAULT 0,
  `alopecia_generalizada` tinyint(4) DEFAULT 0,
  `seco` tinyint(4) DEFAULT 0,
  `oleosos` tinyint(4) DEFAULT 0,
  `normal` tinyint(4) DEFAULT 0,
  `queda_acentuada` tinyint(4) DEFAULT 0,
  `fluorecencia_positiva` tinyint(4) DEFAULT 0,
  `pulga` tinyint(4) DEFAULT 0,
  `piolho` tinyint(4) DEFAULT 0,
  `carrapato` tinyint(4) DEFAULT 0,
  `berne` tinyint(4) DEFAULT 0,
  `parasitologico_positivo` tinyint(4) DEFAULT 0,
  `parasitologico_negativo` tinyint(4) DEFAULT 0,
  `parasitologico_nao_realizado` tinyint(4) DEFAULT 0,
  `fluorecencia_obs` varchar(250) DEFAULT NULL,
  `parasitologico_obs` varchar(250) DEFAULT NULL,
  `otoscopia_direita` varchar(250) DEFAULT NULL,
  `otoscopia_esquerda` varchar(250) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_eletros`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_eletros` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `sensibilidade` decimal(10,2) DEFAULT NULL,
  `frequencia` decimal(10,2) DEFAULT NULL,
  `velocidade` decimal(10,2) DEFAULT NULL,
  `ritmo` decimal(10,2) DEFAULT NULL,
  `eixo` decimal(10,2) DEFAULT NULL,
  `onda_p_d2` decimal(10,2) DEFAULT NULL,
  `qrs_d2` decimal(10,2) DEFAULT NULL,
  `onda_r_d2` decimal(10,2) DEFAULT NULL,
  `espaco_pr_d2` decimal(10,2) DEFAULT NULL,
  `onda_r_cv6lu` decimal(10,2) DEFAULT NULL,
  `onda_s_cv6lu` decimal(10,2) DEFAULT NULL,
  `onda_r_cv6ll` decimal(10,2) DEFAULT NULL,
  `onda_s_cv6ll` decimal(10,2) DEFAULT NULL,
  `onda_t_cv5rl` decimal(10,2) DEFAULT NULL,
  `complexo_qrs_v10` decimal(10,2) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `conclusao` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_fezes`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_fezes` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `aspecto` varchar(30) DEFAULT NULL,
  `consistencia` varchar(30) DEFAULT NULL,
  `cor` varchar(30) DEFAULT NULL,
  `odor` varchar(30) DEFAULT NULL,
  `trichuris_sp` tinyint(4) DEFAULT 0,
  `ancytostoma_sp` tinyint(4) DEFAULT 0,
  `dipilidium_sp` tinyint(4) DEFAULT 0,
  `coccideo` tinyint(4) DEFAULT 0,
  `spirocerca_luppi` tinyint(4) DEFAULT 0,
  `toxoraca_sp` tinyint(4) DEFAULT 0,
  `outros_vermes` tinyint(4) DEFAULT 0,
  `outros_vermes_obs` varchar(30) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_hemogramas`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_hemogramas` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `eritrocitos` decimal(10,2) DEFAULT NULL,
  `hemoglobina` decimal(10,2) DEFAULT NULL,
  `hematrocito` decimal(10,2) DEFAULT NULL,
  `vcm` decimal(10,2) DEFAULT NULL,
  `hcm` decimal(10,2) DEFAULT NULL,
  `chcm` decimal(10,2) DEFAULT NULL,
  `leucocitaria` decimal(10,2) DEFAULT NULL,
  `mielocitos` decimal(10,2) DEFAULT NULL,
  `metamielocitos` decimal(10,2) DEFAULT NULL,
  `nucleo_bastao` decimal(10,2) DEFAULT NULL,
  `nucleo_segmentado` decimal(10,2) DEFAULT NULL,
  `eosinofilo` decimal(10,2) DEFAULT NULL,
  `basofilo` decimal(10,2) DEFAULT NULL,
  `linfocitos` decimal(10,2) DEFAULT NULL,
  `monocitos` decimal(10,2) DEFAULT NULL,
  `plaquetas` decimal(10,2) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_outros`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_outros` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `obs` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_sorologias`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_sorologias` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `brucelose_canina` tinyint(4) DEFAULT 0,
  `dirofilariose` tinyint(4) DEFAULT 0,
  `cinomose` tinyint(4) DEFAULT 0,
  `lyme` tinyint(4) DEFAULT 0,
  `ehrlichia_canis` tinyint(4) DEFAULT 0,
  `pif` tinyint(4) DEFAULT 0,
  `felv` tinyint(4) DEFAULT 0,
  `fiv` tinyint(4) DEFAULT 0,
  `toxoplasmose` tinyint(4) DEFAULT 0,
  `leptospirose` tinyint(4) DEFAULT 0,
  `cinomose_descricao` varchar(50) DEFAULT NULL,
  `pif_descricao` varchar(50) DEFAULT NULL,
  `sorotipos_reagentes` mediumtext DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_ultrasons`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_ultrasons` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `ultrasonografista` varchar(50) DEFAULT NULL,
  `regiao` varchar(50) DEFAULT NULL,
  `bexiga_urinaria` varchar(50) DEFAULT NULL,
  `baco` varchar(50) DEFAULT NULL,
  `figado` varchar(50) DEFAULT NULL,
  `rins` varchar(50) DEFAULT NULL,
  `pancreas` varchar(50) DEFAULT NULL,
  `aorta` varchar(50) DEFAULT NULL,
  `estomago` varchar(50) DEFAULT NULL,
  `linfonodos` varchar(50) DEFAULT NULL,
  `alcas_intestinais` varchar(50) DEFAULT NULL,
  `diafragma` varchar(50) DEFAULT NULL,
  `prostata` varchar(50) DEFAULT NULL,
  `testiculos` varchar(50) DEFAULT NULL,
  `laudo` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_exame_urinas`
--

CREATE TABLE IF NOT EXISTS `agendas_exame_urinas` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1,
  `volume` varchar(30) DEFAULT NULL,
  `cor` varchar(30) DEFAULT NULL,
  `aspecto` varchar(30) DEFAULT NULL,
  `densidade` varchar(30) DEFAULT NULL,
  `proteinas` decimal(10,2) DEFAULT NULL,
  `pigmentos_biliares` decimal(10,2) DEFAULT NULL,
  `glicose` decimal(10,2) DEFAULT NULL,
  `corpos_cetonicos` decimal(10,2) DEFAULT NULL,
  `urobilinogenio` decimal(10,2) DEFAULT NULL,
  `ph` decimal(10,2) DEFAULT NULL,
  `eritrocitos_hemoglobina` decimal(10,2) DEFAULT NULL,
  `nitritos` decimal(10,2) DEFAULT NULL,
  `leucocitos_citologico` decimal(10,2) DEFAULT NULL,
  `eritrocitos` decimal(10,2) DEFAULT NULL,
  `leucocitos` decimal(10,2) DEFAULT NULL,
  `bacteriuria` decimal(10,2) DEFAULT NULL,
  `filamentos_muco` decimal(10,2) DEFAULT NULL,
  `parasitose` decimal(10,2) DEFAULT NULL,
  `tipo_pavimentoso` decimal(10,2) DEFAULT NULL,
  `tipo_uretral` decimal(10,2) DEFAULT NULL,
  `tipo_renal` decimal(10,2) DEFAULT NULL,
  `cilindros` decimal(10,2) DEFAULT NULL,
  `cristais` decimal(10,2) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `resultado` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_hospedagens`
--

CREATE TABLE IF NOT EXISTS `agendas_hospedagens` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `data_saida` date DEFAULT NULL,
  `hora_saida` time DEFAULT NULL,
  `experiencia` tinyint(4) DEFAULT 0,
  `aviso` text DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_internacoes`
--

CREATE TABLE IF NOT EXISTS `agendas_internacoes` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `tipo_internacao` varchar(12) DEFAULT NULL,
  `infeccioso` tinyint(4) DEFAULT 0,
  `sinais` text DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_obs`
--

CREATE TABLE IF NOT EXISTS `agendas_obs` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_repeticoes`
--

CREATE TABLE IF NOT EXISTS `agendas_repeticoes` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `cod_agendas` int(11) DEFAULT NULL,
  `telebusca` varchar(25) DEFAULT NULL,
  `data_("./config_db/config2.php")e` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `dia_semana` varchar(8) DEFAULT NULL,
  `semana` int(11) DEFAULT NULL,
  `periodo` varchar(15) DEFAULT NULL,
  `situacao` enum('Aguardando','Em atendimento','Atendido','Futuro','N?o Compareceu','Cancelou','Marcado','Retorno') DEFAULT 'Marcado'
) ENGINE=MyISAM AUTO_INCREMENT=2993 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_terapeuticas`
--

CREATE TABLE IF NOT EXISTS `agendas_terapeuticas` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `id_agendas` int(11) DEFAULT NULL,
  `cod_estoques` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT 0.00,
  `quantidade_embalagem` decimal(10,2) DEFAULT NULL,
  `quantidade_unidade` decimal(10,2) DEFAULT NULL,
  `unidade` varchar(4) DEFAULT NULL,
  `absorcao` varchar(30) DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendas_vacinas`
--

CREATE TABLE IF NOT EXISTS `agendas_vacinas` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `data_partida` date DEFAULT NULL,
  `numero_partida` varchar(20) DEFAULT NULL,
  `reforco` tinyint(4) DEFAULT 0,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `agressividades`
--

CREATE TABLE IF NOT EXISTS `agressividades` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(120) DEFAULT NULL,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `aliquotas`
--

CREATE TABLE IF NOT EXISTS `aliquotas` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `grupo` int(11) DEFAULT NULL,
  `ordem` int(11) DEFAULT 10000,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `animais`
--

CREATE TABLE IF NOT EXISTS `animais` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_portes` int(11) DEFAULT NULL,
  `cod_lojas` int(11) DEFAULT 0,
  `cod_pelagens` int(11) DEFAULT NULL,
  `cod_especies` int(11) DEFAULT NULL,
  `cod_racas` int(11) DEFAULT NULL,
  `cod_agressividades` int(11) DEFAULT 1,
  `cod_proprietarios` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(45) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `sexo` enum('M','F') DEFAULT NULL,
  `sinais` varchar(50) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `pedigree` enum('Sim','Não') DEFAULT 'Sim',
  `n_pedigree` varchar(15) DEFAULT NULL,
  `data_obito` date DEFAULT NULL,
  `microchip` varchar(15) DEFAULT NULL,
  `aviso` text DEFAULT NULL,
  `tem_aviso` enum('Sim','Não') DEFAULT 'Não',
  `data_cadastro` date DEFAULT NULL,
  `sincronizado` int(11) DEFAULT 0,
  `castrado` enum('Sim','Não') DEFAULT 'Não'
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `apaga`
--

CREATE TABLE IF NOT EXISTS `apaga` (
  `nome` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `bairros`
--

CREATE TABLE IF NOT EXISTS `bairros` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `bancos`
--

CREATE TABLE IF NOT EXISTS `bancos` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `codigo` int(11) DEFAULT NULL,
  `sigla` varchar(30) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `bancos_tipos_contas`
--

CREATE TABLE IF NOT EXISTS `bancos_tipos_contas` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `bandeiras`
--

CREATE TABLE IF NOT EXISTS `bandeiras` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(90) DEFAULT NULL,
  `tipo_bandeira` int(11) DEFAULT NULL,
  `dias_compensacao` int(11) DEFAULT 0,
  `cnpj` varchar(20) DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `caixa_fechamentos`
--

CREATE TABLE IF NOT EXISTS `caixa_fechamentos` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `cod_sessoes` int(11) DEFAULT NULL,
  `cod_pagamentos_formas` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cartas`
--

CREATE TABLE IF NOT EXISTS `cartas` (
  `cod_id` int(11) NOT NULL,
  `cod_relatorios` int(11) DEFAULT NULL,
  `nome` varchar(80) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `carta` text DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `centros_custos`
--

CREATE TABLE IF NOT EXISTS `centros_custos` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(40) DEFAULT NULL,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `centros_custos_subs`
--

CREATE TABLE IF NOT EXISTS `centros_custos_subs` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `cod_centros_custos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(40) DEFAULT NULL,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `clinicas`
--

CREATE TABLE IF NOT EXISTS `clinicas` (
  `cod_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(60) DEFAULT NULL,
  `razao` varchar(200) DEFAULT NULL,
  `endereco` varchar(60) DEFAULT NULL,
  `bairro` varchar(150) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `cep` varchar(15) DEFAULT NULL,
  `ddd` varchar(3) DEFAULT NULL,
  `telefone_clinica` varchar(20) DEFAULT NULL,
  `telefone2_clinica` varchar(20) DEFAULT NULL,
  `email_clinica` varchar(40) DEFAULT NULL,
  `cnpj` varchar(20) DEFAULT NULL,
  `responsavel` varchar(60) DEFAULT NULL,
  `celular_responsavel` varchar(20) DEFAULT NULL,
  `email_responsavel` varchar(40) DEFAULT NULL,
  `email_google` varchar(40) DEFAULT NULL,
  `senha_egoogle` varchar(60) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `comandas_grupos`
--

CREATE TABLE IF NOT EXISTS `comandas_grupos` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `comandas_itens`
--

CREATE TABLE IF NOT EXISTS `comandas_itens` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `cod_comandas_grupos` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `comissoes`
--

CREATE TABLE IF NOT EXISTS `comissoes` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `data_geracao` date DEFAULT NULL,
  `cod_sessao` int(11) DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7188 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `comissoes_tipos`
--

CREATE TABLE IF NOT EXISTS `comissoes_tipos` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE IF NOT EXISTS `configuracoes` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `caixa` int(11) DEFAULT 0,
  `usuario_sms` varchar(50) DEFAULT NULL,
  `senha_sms` varchar(60) DEFAULT NULL,
  `pasta_imagens` varchar(80) DEFAULT NULL,
  `pasta_imagens_old` varchar(80) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `contas`
--

CREATE TABLE IF NOT EXISTS `contas` (
  `cod_id` int(11) NOT NULL,
  `cod_bancos` int(11) DEFAULT NULL,
  `cod_bancos_tipos_contas` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(100) DEFAULT NULL,
  `conta` varchar(15) DEFAULT NULL,
  `agencia` varchar(15) DEFAULT NULL,
  `operacao` varchar(10) DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `contas_extratos`
--

CREATE TABLE IF NOT EXISTS `contas_extratos` (
  `cod_id` int(11) NOT NULL,
  `cod_contas` int(11) DEFAULT NULL,
  `cod_pagamentos` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `conversao`
--

CREATE TABLE IF NOT EXISTS `conversao` (
  `cod_id` int(11) NOT NULL,
  `tabela_origem` varchar(60) DEFAULT NULL,
  `campo_origem` varchar(60) DEFAULT NULL,
  `tabela_destino` varchar(60) DEFAULT NULL,
  `campo_destino` varchar(60) DEFAULT NULL,
  `converter_string` int(11) DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=534 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cores`
--

CREATE TABLE IF NOT EXISTS `cores` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `status` int(11) DEFAULT 2,
  `fonte` varchar(10) DEFAULT NULL,
  `titulo` varchar(12) DEFAULT NULL,
  `miolo` varchar(12) DEFAULT NULL,
  `cor_fechar` varchar(10) DEFAULT NULL,
  `font_cor_fechar` varchar(10) DEFAULT NULL,
  `borda` varchar(12) DEFAULT NULL,
  `menu_esquerda` varchar(12) DEFAULT NULL,
  `janela_menu_esquerda` varchar(10) DEFAULT NULL,
  `menu_item` varchar(12) DEFAULT NULL,
  `miolo_aviso` varchar(20) DEFAULT NULL,
  `miolo_janela` varchar(8) DEFAULT NULL,
  `barra_janela` varchar(10) DEFAULT NULL,
  `font_barra_janela` varchar(10) DEFAULT NULL,
  `botao` varchar(12) DEFAULT NULL,
  `versao` varchar(15) DEFAULT NULL,
  `titulo_janela` varchar(12) DEFAULT NULL,
  `verde` varchar(15) DEFAULT NULL,
  `amarela` varchar(15) DEFAULT NULL,
  `vermelha` varchar(15) DEFAULT NULL,
  `laranja` varchar(15) DEFAULT NULL,
  `azul` varchar(15) DEFAULT NULL,
  `cor_sim` varchar(15) DEFAULT NULL,
  `cor_nao` varchar(15) DEFAULT NULL,
  `cinza_claro` varchar(10) DEFAULT NULL,
  `cinza_medio` varchar(10) DEFAULT NULL,
  `cinza_escuro` varchar(10) DEFAULT NULL,
  `cor_aba` varchar(8) DEFAULT NULL,
  `inverter_imagem` int(11) DEFAULT 0
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `creditos_obs`
--

CREATE TABLE IF NOT EXISTS `creditos_obs` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `cod_agendas` int(11) DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `dividas`
--

CREATE TABLE IF NOT EXISTS `dividas` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(100) DEFAULT NULL,
  `cod_centros_custos` int(11) DEFAULT NULL,
  `cod_agendas` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `dompdf`
--

CREATE TABLE IF NOT EXISTS `dompdf` (
  `cod_id` int(11) NOT NULL,
  `html` text DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `cod_id` int(11) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `mensagem` text DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `data_envio` date DEFAULT NULL,
  `hora_envio` time DEFAULT NULL,
  `assunto` varchar(120) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `prioridade` int(11) DEFAULT 3
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `embalagens`
--

CREATE TABLE IF NOT EXISTS `embalagens` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `entradas_saidas`
--

CREATE TABLE IF NOT EXISTS `entradas_saidas` (
  `cod_id` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `quantidade` decimal(10,2) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `cod_faturas` int(11) DEFAULT NULL,
  `cod_proprietario` int(11) DEFAULT NULL,
  `cod_usuarios` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `especies`
--

CREATE TABLE IF NOT EXISTS `especies` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(20) DEFAULT NULL,
  `p_infect` decimal(10,2) DEFAULT NULL,
  `m_infect` decimal(10,2) DEFAULT NULL,
  `g_infect` decimal(10,2) DEFAULT NULL,
  `gg_infect` decimal(10,2) DEFAULT NULL,
  `p_ninfect` decimal(10,2) DEFAULT NULL,
  `m_ninfect` decimal(10,2) DEFAULT NULL,
  `g_ninfect` decimal(10,2) DEFAULT NULL,
  `gg_ninfect` decimal(10,2) DEFAULT NULL,
  `p_hosp` decimal(10,2) DEFAULT NULL,
  `m_hosp` decimal(10,2) DEFAULT NULL,
  `g_hosp` decimal(10,2) DEFAULT NULL,
  `gg_hosp` decimal(10,2) DEFAULT NULL,
  `mini_infect` decimal(10,2) DEFAULT NULL,
  `mini_ninfect` decimal(10,2) DEFAULT NULL,
  `mini_hosp` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1033 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `estoques`
--

CREATE TABLE IF NOT EXISTS `estoques` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `quantidade` decimal(10,2) DEFAULT NULL,
  `cod_grupos` int(11) DEFAULT NULL,
  `cod_marcas` int(11) DEFAULT NULL,
  `cod_unidades` int(11) DEFAULT NULL,
  `cod_embalagens` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_fornecedores` int(11) DEFAULT NULL,
  `cod_principios_ativos` int(11) DEFAULT NULL,
  `cod_principios_ativos2` int(11) DEFAULT NULL,
  `cod_especies` int(11) DEFAULT NULL,
  `cod_especies2` int(11) DEFAULT NULL,
  `cod_especies3` int(11) DEFAULT NULL,
  `cod_vias_administracao` int(11) DEFAULT NULL,
  `cod_vias_administracao2` int(11) DEFAULT NULL,
  `cod_vias_administracao3` int(11) DEFAULT NULL,
  `cod_centros_custos_subs` int(11) DEFAULT NULL,
  `cod_centros_custos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ceantrib` varchar(15) DEFAULT NULL,
  `cean` varchar(15) DEFAULT NULL,
  `cest` varchar(10) DEFAULT NULL,
  `cfop` varchar(4) DEFAULT NULL,
  `ncm` varchar(20) DEFAULT NULL,
  `cod_situacoes_tributarias` int(11) DEFAULT NULL,
  `cod_aliquotas` int(11) DEFAULT NULL,
  `minimo` decimal(10,2) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `preco_promocao` decimal(10,2) DEFAULT NULL,
  `preco_liquidacao` decimal(10,2) DEFAULT NULL,
  `preco_oferta` decimal(10,2) DEFAULT NULL,
  `preco7` decimal(10,2) DEFAULT NULL,
  `preco6` decimal(10,2) DEFAULT NULL,
  `preco_internacao` decimal(10,2) DEFAULT NULL,
  `preco_custo` decimal(10,2) DEFAULT NULL,
  `quantidade_embalagem` decimal(10,2) DEFAULT NULL,
  `quantidade_fardo` decimal(10,2) DEFAULT NULL,
  `descricao` longtext DEFAULT NULL,
  `tipo` enum('Vacina','Medicamento','Outros') DEFAULT NULL,
  `dias_revacinacao` int(11) DEFAULT NULL,
  `etica` tinyint(4) DEFAULT 0,
  `cod_laboratorios` int(11) DEFAULT NULL,
  `composicao` mediumtext DEFAULT NULL,
  `apresentacao` mediumtext DEFAULT NULL,
  `promocao_tabela` enum('preco','preco_promocao','preco_liquidacao','preco_oferta','preco7','preco6','preco_internacao') DEFAULT 'preco',
  `promocao_quantidade` decimal(10,2) DEFAULT 0.00,
  `promocao_limite` date DEFAULT NULL,
  `comissao` decimal(10,2) DEFAULT 0.00
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `exames`
--

CREATE TABLE IF NOT EXISTS `exames` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(80) DEFAULT NULL,
  `cod_exames_tipos` int(11) DEFAULT NULL,
  `cod_laboratorios` int(11) DEFAULT NULL,
  `dias` int(11) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `exames_bioquimicos`
--

CREATE TABLE IF NOT EXISTS `exames_bioquimicos` (
  `cod_id` int(11) NOT NULL,
  `cod_especies` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `mes_inicial` int(11) DEFAULT NULL,
  `mes_final` int(11) DEFAULT NULL,
  `acido_urico` decimal(10,2) DEFAULT NULL,
  `acidos_biliares` decimal(10,2) DEFAULT NULL,
  `acidos_biliares_jejum` decimal(10,2) DEFAULT NULL,
  `albumina` decimal(10,2) DEFAULT NULL,
  `amilase` decimal(10,2) DEFAULT NULL,
  `alt` decimal(10,2) DEFAULT NULL,
  `ast` decimal(10,2) DEFAULT NULL,
  `bilirrubina_direta` decimal(10,2) DEFAULT NULL,
  `bilirrubina_indireta` decimal(10,2) DEFAULT NULL,
  `bilirrubina_total` decimal(10,2) DEFAULT NULL,
  `calcio` decimal(10,2) DEFAULT NULL,
  `colesterol` decimal(10,2) DEFAULT NULL,
  `ck` decimal(10,2) DEFAULT NULL,
  `creatina` decimal(10,2) DEFAULT NULL,
  `digoxina` decimal(10,2) DEFAULT NULL,
  `fibrinogenio` decimal(10,2) DEFAULT NULL,
  `fosforo` decimal(10,2) DEFAULT NULL,
  `frutosamina` decimal(10,2) DEFAULT NULL,
  `ggt` decimal(10,2) DEFAULT NULL,
  `glicose` decimal(10,2) DEFAULT NULL,
  `globulina` decimal(10,2) DEFAULT NULL,
  `hemoglobina` decimal(10,2) DEFAULT NULL,
  `lipase` decimal(10,2) DEFAULT NULL,
  `fosfatase_alcalina` decimal(10,2) DEFAULT NULL,
  `fosfatase_alcalina_doze` decimal(10,2) DEFAULT NULL,
  `potassio` decimal(10,2) DEFAULT NULL,
  `proteina` decimal(10,2) DEFAULT NULL,
  `sodio` decimal(10,2) DEFAULT NULL,
  `ureia` decimal(10,2) DEFAULT NULL,
  `triglicerides` decimal(10,2) DEFAULT NULL,
  `acido_urico_max` decimal(10,2) DEFAULT NULL,
  `acidos_biliares_max` decimal(10,2) DEFAULT NULL,
  `acidos_biliares_jejum_max` decimal(10,2) DEFAULT NULL,
  `albumina_max` decimal(10,2) DEFAULT NULL,
  `amilase_max` decimal(10,2) DEFAULT NULL,
  `alt_max` decimal(10,2) DEFAULT NULL,
  `ast_max` decimal(10,2) DEFAULT NULL,
  `bilirrubina_direta_max` decimal(10,2) DEFAULT NULL,
  `bilirrubina_indireta_max` decimal(10,2) DEFAULT NULL,
  `bilirrubina_total_max` decimal(10,2) DEFAULT NULL,
  `calcio_max` decimal(10,2) DEFAULT NULL,
  `colesterol_max` decimal(10,2) DEFAULT NULL,
  `ck_max` decimal(10,2) DEFAULT NULL,
  `creatina_max` decimal(10,2) DEFAULT NULL,
  `digoxina_max` decimal(10,2) DEFAULT NULL,
  `fibrinogenio_max` decimal(10,2) DEFAULT NULL,
  `fosforo_max` decimal(10,2) DEFAULT NULL,
  `frutosamina_max` decimal(10,2) DEFAULT NULL,
  `ggt_max` decimal(10,2) DEFAULT NULL,
  `glicose_max` decimal(10,2) DEFAULT NULL,
  `globulina_max` decimal(10,2) DEFAULT NULL,
  `hemoglobina_max` decimal(10,2) DEFAULT NULL,
  `lipase_max` decimal(10,2) DEFAULT NULL,
  `fosfatase_alcalina_max` decimal(10,2) DEFAULT NULL,
  `fosfatase_alcalina_doze_max` decimal(10,2) DEFAULT NULL,
  `potassio_max` decimal(10,2) DEFAULT NULL,
  `proteina_max` decimal(10,2) DEFAULT NULL,
  `sodio_max` decimal(10,2) DEFAULT NULL,
  `ureia_max` decimal(10,2) DEFAULT NULL,
  `triglicerides_max` decimal(10,2) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `exames_hemogramas`
--

CREATE TABLE IF NOT EXISTS `exames_hemogramas` (
  `cod_id` int(11) NOT NULL,
  `cod_especies` int(11) DEFAULT NULL,
  `mes_inicial` int(11) DEFAULT NULL,
  `mes_final` int(11) DEFAULT NULL,
  `eritrocito_min` decimal(10,2) DEFAULT NULL,
  `hemoglobina_min` decimal(10,2) DEFAULT NULL,
  `hematocrito_min` decimal(10,2) DEFAULT NULL,
  `vcm_min` decimal(10,2) DEFAULT NULL,
  `hcm_min` decimal(10,2) DEFAULT NULL,
  `chcm_min` decimal(10,2) DEFAULT NULL,
  `leucocitos_min` decimal(10,2) DEFAULT NULL,
  `mielocitos_min` decimal(10,2) DEFAULT NULL,
  `metamielocitos_min` decimal(10,2) DEFAULT NULL,
  `nucleo_bastao_min` decimal(10,2) DEFAULT NULL,
  `nucleo_segmentado_min` decimal(10,2) DEFAULT NULL,
  `eosinofilos_min` decimal(10,2) DEFAULT NULL,
  `basofilos_min` decimal(10,2) DEFAULT NULL,
  `linfocitos_min` decimal(10,2) DEFAULT NULL,
  `monocitos_min` decimal(10,2) DEFAULT NULL,
  `plaquetas_min` decimal(10,2) DEFAULT NULL,
  `eritrocito_max` decimal(10,2) DEFAULT NULL,
  `hemoglobina_max` decimal(10,2) DEFAULT NULL,
  `hematocrito_max` decimal(10,2) DEFAULT NULL,
  `vcm_max` decimal(10,2) DEFAULT NULL,
  `hcm_max` decimal(10,2) DEFAULT NULL,
  `chcm_max` decimal(10,2) DEFAULT NULL,
  `leucocitos_max` decimal(10,2) DEFAULT NULL,
  `mielocitos_max` decimal(10,2) DEFAULT NULL,
  `metamielocitos_max` decimal(10,2) DEFAULT NULL,
  `nucleo_bastao_max` decimal(10,2) DEFAULT NULL,
  `nucleo_segmentado_max` decimal(10,2) DEFAULT NULL,
  `eosinofilos_max` decimal(10,2) DEFAULT NULL,
  `basofilos_max` decimal(10,2) DEFAULT NULL,
  `linfocitos_max` decimal(10,2) DEFAULT NULL,
  `monocitos_max` decimal(10,2) DEFAULT NULL,
  `plaquetas_max` decimal(10,2) DEFAULT NULL,
  `mielocitos_relativos_min` decimal(10,2) DEFAULT NULL,
  `metamielocitos_relativos_min` decimal(10,2) DEFAULT NULL,
  `nucleo_bastao_relativos_min` decimal(10,2) DEFAULT NULL,
  `nucleo_segmentado_relativos_min` decimal(10,2) DEFAULT NULL,
  `eosinofilos_relativos_min` decimal(10,2) DEFAULT NULL,
  `basofilos_relativos_min` decimal(10,2) DEFAULT NULL,
  `linfocitos_relativos_min` decimal(10,2) DEFAULT NULL,
  `monocitos_relativos_min` decimal(10,2) DEFAULT NULL,
  `mielocitos_relativos_max` decimal(10,2) DEFAULT NULL,
  `metamielocitos_relativos_max` decimal(10,2) DEFAULT NULL,
  `nucleo_bastao_relativos_max` decimal(10,2) DEFAULT NULL,
  `nucleo_segmentado_relativos_max` decimal(10,2) DEFAULT NULL,
  `eosinofilos_relativos_max` decimal(10,2) DEFAULT NULL,
  `basofilos_relativos_max` decimal(10,2) DEFAULT NULL,
  `linfocitos_relativos_max` decimal(10,2) DEFAULT NULL,
  `monocitos_relativos_max` decimal(10,2) DEFAULT NULL,
  `proteinas_min` decimal(10,2) DEFAULT NULL,
  `proteinas_max` decimal(10,2) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `linfocitos_atipicos_min` decimal(10,2) DEFAULT NULL,
  `linfocitos_atipicos_max` decimal(10,2) DEFAULT NULL,
  `linfocitos_atipicos_relativos_min` decimal(10,2) DEFAULT NULL,
  `linfocitos_atipicos_relativos_max` decimal(10,2) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `exames_interpretacoes`
--

CREATE TABLE IF NOT EXISTS `exames_interpretacoes` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `tabela` varchar(60) DEFAULT NULL,
  `label_tabela` varchar(60) DEFAULT NULL,
  `campo` varchar(60) DEFAULT NULL,
  `label_campo` varchar(60) DEFAULT NULL,
  `tipo` varchar(15) DEFAULT NULL,
  `comparacao` varchar(15) DEFAULT NULL,
  `valor` varchar(60) DEFAULT NULL,
  `interpretacao` mediumtext DEFAULT NULL,
  `cod_clinica` int(11) DEFAULT 0
) ENGINE=MyISAM AUTO_INCREMENT=538 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `exames_tipos`
--

CREATE TABLE IF NOT EXISTS `exames_tipos` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `faturas`
--

CREATE TABLE IF NOT EXISTS `faturas` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `cod_usuarios` int(11) DEFAULT NULL,
  `cod_sessoes` int(11) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `nf` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1239 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `feriados`
--

CREATE TABLE IF NOT EXISTS `feriados` (
  `cod_id` int(11) NOT NULL,
  `dia` int(11) DEFAULT NULL,
  `mes` int(11) DEFAULT NULL,
  `ano` int(11) DEFAULT NULL,
  `texto` varchar(30) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `financeiros`
--

CREATE TABLE IF NOT EXISTS `financeiros` (
  `cod_id` int(11) NOT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `data_consulta` date DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `sessao` int(11) DEFAULT NULL,
  `fatura` int(11) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `animal` varchar(90) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `descricao` varchar(80) DEFAULT NULL,
  `selecionado` int(11) DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=36977 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `fornecedores`
--

CREATE TABLE IF NOT EXISTS `fornecedores` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_bancos_tipos_contas` int(11) DEFAULT NULL,
  `cod_bancos` int(11) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `conta` varchar(15) DEFAULT NULL,
  `agencia` varchar(15) DEFAULT NULL,
  `operacao` varchar(10) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `razao_social` varchar(200) DEFAULT NULL,
  `cnpj` varchar(18) DEFAULT NULL,
  `inscricao_estadual` varchar(18) DEFAULT NULL,
  `endereco` varchar(60) DEFAULT NULL,
  `bairro` varchar(25) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `cep` varchar(8) DEFAULT NULL,
  `telefone` varchar(12) DEFAULT NULL,
  `telefone2` varchar(12) DEFAULT NULL,
  `celular` varchar(12) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `contato` varchar(50) DEFAULT NULL,
  `celular_contato` varchar(15) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `fotos`
--

CREATE TABLE IF NOT EXISTS `fotos` (
  `cod_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(200) DEFAULT NULL,
  `cod_sessao` int(11) DEFAULT 0,
  `foto` longtext DEFAULT NULL,
  `cod_local` int(11) DEFAULT 0,
  `data` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM AUTO_INCREMENT=1372 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `graficos`
--

CREATE TABLE IF NOT EXISTS `graficos` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `query` mediumtext DEFAULT NULL,
  `sessao` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `grupos`
--

CREATE TABLE IF NOT EXISTS `grupos` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `nome` varchar(60) DEFAULT NULL,
  `comissao` decimal(10,2) DEFAULT 0.00,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `janelas_permissoes`
--

CREATE TABLE IF NOT EXISTS `janelas_permissoes` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `apelido` varchar(50) DEFAULT NULL,
  `soadm` int(11) DEFAULT 0,
  `usuarios_permissoes1` varchar(50) NOT NULL,
  `usuarios_permissoes2` varchar(50) NOT NULL,
  `socaixa_aberto` int(11) DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `laboratorios`
--

CREATE TABLE IF NOT EXISTS `laboratorios` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_bancos` int(11) DEFAULT NULL,
  `cod_bancos_tipos_contas` int(11) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `conta` varchar(15) DEFAULT NULL,
  `agencia` varchar(15) DEFAULT NULL,
  `operacao` varchar(10) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `razao_social` varchar(50) DEFAULT NULL,
  `cnpj` varchar(18) DEFAULT NULL,
  `inscricao_estadual` varchar(18) DEFAULT NULL,
  `endereco` varchar(60) DEFAULT NULL,
  `bairro` varchar(25) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `cep` varchar(8) DEFAULT NULL,
  `telefone` varchar(12) DEFAULT NULL,
  `telefone2` varchar(12) DEFAULT NULL,
  `celular` varchar(12) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `contato` varchar(50) DEFAULT NULL,
  `celular_contato` varchar(15) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `cod_id` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `tabela` varchar(30) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `sessao` int(11) DEFAULT NULL,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=923 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `cod_id` int(11) NOT NULL,
  `cod_sessao` int(11) DEFAULT NULL,
  `informacao` text DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `lojas`
--

CREATE TABLE IF NOT EXISTS `lojas` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `marcas`
--

CREATE TABLE IF NOT EXISTS `marcas` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `nome` varchar(60) DEFAULT NULL,
  `comissao` decimal(10,2) DEFAULT 0.00,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `orgaos`
--

CREATE TABLE IF NOT EXISTS `orgaos` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `cod_sistemas` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos`
--

CREATE TABLE IF NOT EXISTS `pagamentos` (
  `cod_id` int(11) NOT NULL,
  `cod_bandeiras` int(11) DEFAULT 1000,
  `parcelas` int(11) DEFAULT 1,
  `cod_pagamentos_formas` int(11) DEFAULT NULL,
  `cod_faturas` int(11) DEFAULT NULL,
  `cod_proprietarios` int(11) DEFAULT NULL,
  `cod_contas` int(11) DEFAULT 1,
  `cod_sessoes` int(11) DEFAULT 0,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `vencimento` date DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `descricao` varchar(100) DEFAULT NULL,
  `caixa` tinyint(4) DEFAULT 0,
  `compensado` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=808 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos_bandeiras`
--

CREATE TABLE IF NOT EXISTS `pagamentos_bandeiras` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `codigo` int(11) DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos_formas`
--

CREATE TABLE IF NOT EXISTS `pagamentos_formas` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `codigo` int(11) DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL,
  `dias_compensacao` int(11) DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=1003 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `patologias`
--

CREATE TABLE IF NOT EXISTS `patologias` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `nome` varchar(80) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `obs` text DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pelagens`
--

CREATE TABLE IF NOT EXISTS `pelagens` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(50) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pelos`
--

CREATE TABLE IF NOT EXISTS `pelos` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `status` int(11) DEFAULT 1,
  `nome` varchar(50) DEFAULT NULL,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `portes`
--

CREATE TABLE IF NOT EXISTS `portes` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(25) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `principios_ativos`
--

CREATE TABLE IF NOT EXISTS `principios_ativos` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `indicacao` mediumtext DEFAULT NULL,
  `farmacologia` mediumtext DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `dose_unidade` varchar(80) DEFAULT NULL,
  `dose_outros` varchar(100) DEFAULT NULL,
  `dose_gato` varchar(100) DEFAULT NULL,
  `dose_cao` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=472 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `principios_ativos_interacoes`
--

CREATE TABLE IF NOT EXISTS `principios_ativos_interacoes` (
  `cod_id` int(11) NOT NULL,
  `cod_principios_ativos` int(11) DEFAULT NULL,
  `cod_principios_ativos2` int(11) DEFAULT NULL,
  `tipo_interacao` varchar(60) DEFAULT NULL,
  `grau_interacao` varchar(30) DEFAULT NULL,
  `efeito_clinico` varchar(250) DEFAULT NULL,
  `mecanismo` varchar(60) DEFAULT NULL,
  `conduto` varchar(60) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `proprietarios`
--

CREATE TABLE IF NOT EXISTS `proprietarios` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_filial` int(11) DEFAULT 0,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(50) DEFAULT NULL,
  `sobrenome` varchar(50) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `bairro` varchar(80) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `fone_residencial` varchar(20) DEFAULT NULL,
  `fone_comercial` varchar(20) DEFAULT NULL,
  `ramal` varchar(6) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `rg` varchar(25) DEFAULT NULL,
  `celular` varchar(25) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `emailb` varchar(150) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `credito` decimal(10,2) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  `mala` tinyint(4) DEFAULT 1,
  `pessoa_fisica` tinyint(4) DEFAULT 1,
  `juros` decimal(10,2) DEFAULT NULL,
  `limite_credito` decimal(10,2) DEFAULT NULL,
  `classificacao` int(11) DEFAULT 0,
  `contato_recado` varchar(80) DEFAULT NULL,
  `fone_recado` varchar(30) DEFAULT NULL,
  `profissao` varchar(30) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `proprietarios_apaga`
--

CREATE TABLE IF NOT EXISTS `proprietarios_apaga` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(50) DEFAULT NULL,
  `sobrenome` varchar(50) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `bairro` varchar(40) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `fone_residencial` varchar(20) DEFAULT NULL,
  `fone_comercial` varchar(20) DEFAULT NULL,
  `ramal` varchar(6) DEFAULT NULL,
  `obs` mediumtext DEFAULT NULL,
  `rg` varchar(25) DEFAULT NULL,
  `celular` varchar(25) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `emailb` varchar(150) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `credito` decimal(10,2) DEFAULT NULL,
  `data_cadastro` date DEFAULT NULL,
  `mala` tinyint(4) DEFAULT 1,
  `pessoa_fisica` tinyint(4) DEFAULT 1,
  `juros` decimal(10,2) DEFAULT NULL,
  `limite_credito` decimal(10,2) DEFAULT NULL,
  `classificacao` int(11) DEFAULT 0,
  `contato_recado` varchar(80) DEFAULT NULL,
  `fone_recado` varchar(30) DEFAULT NULL,
  `profissao` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `racas`
--

CREATE TABLE IF NOT EXISTS `racas` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_especies` int(11) DEFAULT NULL,
  `cod_pelos` int(11) DEFAULT NULL,
  `cod_portes` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(60) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=162 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `relatorios_categorias_old`
--

CREATE TABLE IF NOT EXISTS `relatorios_categorias_old` (
  `cod_id` int(11) NOT NULL,
  `categoria` varchar(35) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `relatorios_old`
--

CREATE TABLE IF NOT EXISTS `relatorios_old` (
  `cod_id` int(11) NOT NULL,
  `relatorio` varchar(200) DEFAULT NULL,
  `titulo` varchar(200) DEFAULT NULL,
  `campo_soma` varchar(50) DEFAULT 'no',
  `titulo_soma` varchar(100) DEFAULT NULL,
  `digite` varchar(150) DEFAULT NULL,
  `query` text DEFAULT NULL,
  `tipo` varchar(30) DEFAULT NULL,
  `sql_valores` varchar(200) DEFAULT '0',
  `sql_valores2` varchar(200) DEFAULT NULL,
  `cod_categorias` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos`
--

CREATE TABLE IF NOT EXISTS `servicos` (
  `cod_id` int(11) NOT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_centros_custos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(120) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `comissao` decimal(10,2) DEFAULT 0.00,
  `tipo` varchar(12) DEFAULT NULL,
  `cod_valores` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos_detalhes`
--

CREATE TABLE IF NOT EXISTS `servicos_detalhes` (
  `cod_id` int(11) NOT NULL,
  `cod_servicos` int(11) DEFAULT NULL,
  `cod_fornecedores` int(11) DEFAULT 1,
  `dias` int(11) DEFAULT 0,
  `obs` mediumtext DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos_estoques`
--

CREATE TABLE IF NOT EXISTS `servicos_estoques` (
  `cod_id` int(11) NOT NULL,
  `cod_servicos` int(11) DEFAULT NULL,
  `cod_estoques` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `sessoes`
--

CREATE TABLE IF NOT EXISTS `sessoes` (
  `cod_id` int(11) NOT NULL,
  `cod_usuarios` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1,
  `data_inicio` date DEFAULT NULL,
  `hora_inicio` time DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `hora_fim` time DEFAULT NULL,
  `obs` varchar(50) DEFAULT NULL,
  `cod_foto_mostra` int(11) DEFAULT 0
) ENGINE=MyISAM AUTO_INCREMENT=20161 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `sintomas`
--

CREATE TABLE IF NOT EXISTS `sintomas` (
  `cod_id` int(11) NOT NULL,
  `cod_sistemas` int(11) DEFAULT NULL,
  `cod_orgaos` int(11) DEFAULT NULL,
  `nome` varchar(80) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `sintomas_patologias`
--

CREATE TABLE IF NOT EXISTS `sintomas_patologias` (
  `cod_id` int(11) NOT NULL,
  `cod_patologias` int(11) DEFAULT NULL,
  `cod_sintomas` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `sistemas`
--

CREATE TABLE IF NOT EXISTS `sistemas` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=10001 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `situacoes_tributarias`
--

CREATE TABLE IF NOT EXISTS `situacoes_tributarias` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `grupo` int(11) DEFAULT NULL,
  `ordem` int(11) DEFAULT 10000,
  `status` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tamanhos`
--

CREATE TABLE IF NOT EXISTS `tamanhos` (
  `cod_id` int(11) NOT NULL,
  `botao_navigator` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `taxas`
--

CREATE TABLE IF NOT EXISTS `taxas` (
  `cod_id` int(11) NOT NULL,
  `status` int(11) DEFAULT 1,
  `nome` varchar(120) DEFAULT NULL,
  `tabela` varchar(25) DEFAULT NULL,
  `campo` varchar(25) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `taxas_descricoes`
--

CREATE TABLE IF NOT EXISTS `taxas_descricoes` (
  `cod_id` int(11) NOT NULL,
  `cod_taxas_detalhes` int(11) DEFAULT NULL,
  `cod_agendas` int(11) DEFAULT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `valor` decimal(10,2) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1760 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `taxas_detalhes`
--

CREATE TABLE IF NOT EXISTS `taxas_detalhes` (
  `cod_id` int(11) NOT NULL,
  `cod_taxas` int(11) DEFAULT NULL,
  `id_registro` int(11) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `cod_servico` int(11) DEFAULT NULL,
  `taxa` decimal(10,2) DEFAULT NULL,
  `hora_inicial` time DEFAULT NULL,
  `hora_final` time DEFAULT NULL,
  `data_inicial` date DEFAULT NULL,
  `data_final` date DEFAULT NULL,
  `mesma_nota` int(11) DEFAULT 1,
  `status` int(11) DEFAULT 1,
  `seg` tinyint(4) DEFAULT 1,
  `ter` tinyint(4) DEFAULT 1,
  `qua` tinyint(4) DEFAULT 1,
  `qui` tinyint(4) DEFAULT 1,
  `sex` tinyint(4) DEFAULT 1,
  `sab` tinyint(4) DEFAULT 1,
  `dom` tinyint(4) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=301 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `unidades`
--

CREATE TABLE IF NOT EXISTS `unidades` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(20) DEFAULT NULL,
  `organica` tinyint(4) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `cod_id` int(11) NOT NULL,
  `cod_usuarios_cargos` int(11) DEFAULT NULL,
  `cod_fotos` int(11) DEFAULT 1,
  `cod_bancos_tipos_contas` int(11) DEFAULT NULL,
  `cod_bancos` int(11) DEFAULT NULL,
  `cod_comissoes_tipos` int(11) DEFAULT NULL,
  `cod_centros_custos` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1,
  `administrador` tinyint(4) DEFAULT 0,
  `operacao` varchar(10) DEFAULT NULL,
  `agencia` varchar(15) DEFAULT NULL,
  `conta` varchar(15) DEFAULT NULL,
  `nome` varchar(40) DEFAULT NULL,
  `senha` varchar(150) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `salario` decimal(10,2) DEFAULT 0.00,
  `comissao_venda` decimal(10,2) DEFAULT 0.00,
  `comissao_servico` decimal(10,2) DEFAULT 0.00,
  `comissao_hospedagem` decimal(10,2) DEFAULT 0.00,
  `comissao_internacao` decimal(10,2) DEFAULT 0.00,
  `comissao_estetica` decimal(10,2) DEFAULT 0.00,
  `comissao_diversos` decimal(10,2) DEFAULT 0.00,
  `comissao_vacina` decimal(10,2) DEFAULT 0.00,
  `comissao_exame` decimal(10,2) DEFAULT 0.00,
  `comissao_cirurgia` decimal(10,2) DEFAULT 0.00,
  `comissao_consulta` decimal(10,2) DEFAULT 0.00,
  `crmv` varchar(20) DEFAULT NULL,
  `cpf` varchar(20) DEFAULT NULL,
  `fone` varchar(15) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `cep` varchar(12) DEFAULT NULL,
  `endereco` varchar(50) DEFAULT NULL,
  `cidade` varchar(20) DEFAULT NULL,
  `bairro` varchar(25) DEFAULT NULL,
  `celular` varchar(20) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `emoji` int(11) DEFAULT 0
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios_cargos`
--

CREATE TABLE IF NOT EXISTS `usuarios_cargos` (
  `cod_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT 1,
  `nome` varchar(50) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios_permissoes`
--

CREATE TABLE IF NOT EXISTS `usuarios_permissoes` (
  `cod_id` int(11) NOT NULL,
  `cod_usuarios` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT 1,
  `geral_imprime` tinyint(4) DEFAULT 1,
  `geral_exclui` tinyint(4) DEFAULT 1,
  `geral_altera` tinyint(4) DEFAULT 1,
  `geral_inclui` tinyint(4) DEFAULT 1,
  `geral_cartas` tinyint(4) DEFAULT 1,
  `geral_estorna` tinyint(4) DEFAULT 1,
  `geral_filiais` tinyint(4) DEFAULT 1,
  `cadastro_animal` tinyint(4) DEFAULT 1,
  `cadastro_clinico` tinyint(4) DEFAULT 1,
  `cadastro_medicamento` tinyint(4) DEFAULT 1,
  `cadastro_estetica` tinyint(4) DEFAULT 1,
  `cadastro_estoque` tinyint(4) DEFAULT 1,
  `cadastro_proprietario` tinyint(4) DEFAULT 1,
  `cadastro_fornecedor` tinyint(4) DEFAULT 1,
  `cadastro_ccusto` tinyint(4) DEFAULT 1,
  `cadastro_funcionario` tinyint(4) DEFAULT 1,
  `cadastro_texto` tinyint(4) DEFAULT 1,
  `acompanhamento_menu` tinyint(4) DEFAULT 1,
  `acompanhamento_agenda_retorno` tinyint(4) DEFAULT 1,
  `acompanhamento_medicamento` tinyint(4) DEFAULT 1,
  `acompanhamento_internacao` tinyint(4) DEFAULT 1,
  `acompanhamento_exame` tinyint(4) DEFAULT 1,
  `acompanhamento_estetica` tinyint(4) DEFAULT 1,
  `acompanhamento_agenda_clinica` tinyint(4) DEFAULT 1,
  `hospedagem_menu` tinyint(4) DEFAULT 1,
  `hospedagem_reserva` tinyint(4) DEFAULT 1,
  `estetica_menu` tinyint(4) DEFAULT 1,
  `petshop_menu` tinyint(4) DEFAULT 1,
  `petshop_lista_preco` tinyint(4) DEFAULT 1,
  `petshop_estoque` tinyint(4) DEFAULT 1,
  `petshop_compra` tinyint(4) DEFAULT 1,
  `petshop_venda` tinyint(4) DEFAULT 1,
  `petshop_controle_venda` tinyint(4) DEFAULT 1,
  `petshop_entrada_saida` tinyint(4) DEFAULT 1,
  `financeiro_menu` tinyint(4) DEFAULT 1,
  `financeiro_servico_ncobrado` tinyint(4) DEFAULT 1,
  `financeiro_servico_cobrado` tinyint(4) DEFAULT 1,
  `financeiro_movimento` tinyint(4) DEFAULT 1,
  `financeiro_salario` tinyint(4) DEFAULT 1,
  `financeiro_relatorio` tinyint(4) DEFAULT 1,
  `financeiro_centro_custo` tinyint(4) DEFAULT 1,
  `financeiro_atividade` tinyint(4) DEFAULT 1,
  `financeiro_caixa` tinyint(4) DEFAULT 1,
  `financeiro_fatura` tinyint(4) DEFAULT 1
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `valores`
--

CREATE TABLE IF NOT EXISTS `valores` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `grupo` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=232 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `variaveis`
--

CREATE TABLE IF NOT EXISTS `variaveis` (
  `cod_id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT 1,
  `calendario_dia` int(11) DEFAULT NULL,
  `calendario_mes` int(11) DEFAULT NULL,
  `calendario_ano` int(11) DEFAULT NULL,
  `cod_sessao` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=22699 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `vendas`
--

CREATE TABLE IF NOT EXISTS `vendas` (
  `cod_id` int(11) NOT NULL,
  `cod_estoques` int(11) DEFAULT NULL,
  `cod_usuarios` int(11) DEFAULT 0,
  `cod_sessao` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `grupo` int(11) DEFAULT 0,
  `tipo` varchar(10) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `quantidade` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1463 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `vias_administracao`
--

CREATE TABLE IF NOT EXISTS `vias_administracao` (
  `cod_id` int(11) NOT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `ordem` int(11) DEFAULT 10000
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `xmls`
--

CREATE TABLE IF NOT EXISTS `xmls` (
  `cod_id` int(11) NOT NULL,
  `grupo` int(11) DEFAULT NULL,
  `tag_pai` varchar(100) DEFAULT NULL,
  `tag_abertura` varchar(100) DEFAULT NULL,
  `tag_fechamento` varchar(100) DEFAULT NULL,
  `tabela_destino` varchar(100) DEFAULT NULL,
  `campo_destino` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `a1retornos`
--
ALTER TABLE `a1retornos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas`
--
ALTER TABLE `agendas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_cirurgias`
--
ALTER TABLE `agendas_cirurgias`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_consultas`
--
ALTER TABLE `agendas_consultas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_diversos`
--
ALTER TABLE `agendas_diversos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_esteticas`
--
ALTER TABLE `agendas_esteticas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_esteticas_comandas`
--
ALTER TABLE `agendas_esteticas_comandas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_bioquimicos`
--
ALTER TABLE `agendas_exame_bioquimicos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_cavitarios`
--
ALTER TABLE `agendas_exame_cavitarios`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_citologias`
--
ALTER TABLE `agendas_exame_citologias`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_dermatologicos`
--
ALTER TABLE `agendas_exame_dermatologicos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_eletros`
--
ALTER TABLE `agendas_exame_eletros`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_fezes`
--
ALTER TABLE `agendas_exame_fezes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_hemogramas`
--
ALTER TABLE `agendas_exame_hemogramas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_outros`
--
ALTER TABLE `agendas_exame_outros`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_sorologias`
--
ALTER TABLE `agendas_exame_sorologias`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_ultrasons`
--
ALTER TABLE `agendas_exame_ultrasons`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_exame_urinas`
--
ALTER TABLE `agendas_exame_urinas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_hospedagens`
--
ALTER TABLE `agendas_hospedagens`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_internacoes`
--
ALTER TABLE `agendas_internacoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_obs`
--
ALTER TABLE `agendas_obs`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_repeticoes`
--
ALTER TABLE `agendas_repeticoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_terapeuticas`
--
ALTER TABLE `agendas_terapeuticas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agendas_vacinas`
--
ALTER TABLE `agendas_vacinas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `agressividades`
--
ALTER TABLE `agressividades`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `aliquotas`
--
ALTER TABLE `aliquotas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `animais`
--
ALTER TABLE `animais`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `bairros`
--
ALTER TABLE `bairros`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `bancos`
--
ALTER TABLE `bancos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `bancos_tipos_contas`
--
ALTER TABLE `bancos_tipos_contas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `bandeiras`
--
ALTER TABLE `bandeiras`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `caixa_fechamentos`
--
ALTER TABLE `caixa_fechamentos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `cartas`
--
ALTER TABLE `cartas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `centros_custos`
--
ALTER TABLE `centros_custos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `centros_custos_subs`
--
ALTER TABLE `centros_custos_subs`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `clinicas`
--
ALTER TABLE `clinicas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `comandas_grupos`
--
ALTER TABLE `comandas_grupos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `comandas_itens`
--
ALTER TABLE `comandas_itens`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `comissoes`
--
ALTER TABLE `comissoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `comissoes_tipos`
--
ALTER TABLE `comissoes_tipos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `contas`
--
ALTER TABLE `contas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `contas_extratos`
--
ALTER TABLE `contas_extratos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `conversao`
--
ALTER TABLE `conversao`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `cores`
--
ALTER TABLE `cores`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `creditos_obs`
--
ALTER TABLE `creditos_obs`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `dividas`
--
ALTER TABLE `dividas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `dompdf`
--
ALTER TABLE `dompdf`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `embalagens`
--
ALTER TABLE `embalagens`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `entradas_saidas`
--
ALTER TABLE `entradas_saidas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `especies`
--
ALTER TABLE `especies`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `estoques`
--
ALTER TABLE `estoques`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `exames`
--
ALTER TABLE `exames`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `exames_bioquimicos`
--
ALTER TABLE `exames_bioquimicos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `exames_hemogramas`
--
ALTER TABLE `exames_hemogramas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `exames_interpretacoes`
--
ALTER TABLE `exames_interpretacoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `exames_tipos`
--
ALTER TABLE `exames_tipos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `faturas`
--
ALTER TABLE `faturas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `feriados`
--
ALTER TABLE `feriados`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `financeiros`
--
ALTER TABLE `financeiros`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `fotos`
--
ALTER TABLE `fotos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `graficos`
--
ALTER TABLE `graficos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `grupos`
--
ALTER TABLE `grupos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `janelas_permissoes`
--
ALTER TABLE `janelas_permissoes`
  ADD PRIMARY KEY (`cod_id`), ADD UNIQUE KEY `nome` (`nome`);

--
-- Índices de tabela `laboratorios`
--
ALTER TABLE `laboratorios`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `lojas`
--
ALTER TABLE `lojas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `marcas`
--
ALTER TABLE `marcas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `orgaos`
--
ALTER TABLE `orgaos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `pagamentos_bandeiras`
--
ALTER TABLE `pagamentos_bandeiras`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `pagamentos_formas`
--
ALTER TABLE `pagamentos_formas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `patologias`
--
ALTER TABLE `patologias`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `pelagens`
--
ALTER TABLE `pelagens`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `pelos`
--
ALTER TABLE `pelos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `portes`
--
ALTER TABLE `portes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `principios_ativos`
--
ALTER TABLE `principios_ativos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `principios_ativos_interacoes`
--
ALTER TABLE `principios_ativos_interacoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `proprietarios`
--
ALTER TABLE `proprietarios`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `proprietarios_apaga`
--
ALTER TABLE `proprietarios_apaga`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `racas`
--
ALTER TABLE `racas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `relatorios_categorias_old`
--
ALTER TABLE `relatorios_categorias_old`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `relatorios_old`
--
ALTER TABLE `relatorios_old`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `servicos`
--
ALTER TABLE `servicos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `servicos_detalhes`
--
ALTER TABLE `servicos_detalhes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `servicos_estoques`
--
ALTER TABLE `servicos_estoques`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `sessoes`
--
ALTER TABLE `sessoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `sintomas`
--
ALTER TABLE `sintomas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `sintomas_patologias`
--
ALTER TABLE `sintomas_patologias`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `sistemas`
--
ALTER TABLE `sistemas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `situacoes_tributarias`
--
ALTER TABLE `situacoes_tributarias`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `tamanhos`
--
ALTER TABLE `tamanhos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `taxas`
--
ALTER TABLE `taxas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `taxas_descricoes`
--
ALTER TABLE `taxas_descricoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `taxas_detalhes`
--
ALTER TABLE `taxas_detalhes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `unidades`
--
ALTER TABLE `unidades`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `usuarios_cargos`
--
ALTER TABLE `usuarios_cargos`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `usuarios_permissoes`
--
ALTER TABLE `usuarios_permissoes`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `valores`
--
ALTER TABLE `valores`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `variaveis`
--
ALTER TABLE `variaveis`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `vias_administracao`
--
ALTER TABLE `vias_administracao`
  ADD PRIMARY KEY (`cod_id`);

--
-- Índices de tabela `xmls`
--
ALTER TABLE `xmls`
  ADD PRIMARY KEY (`cod_id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `a1retornos`
--
ALTER TABLE `a1retornos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT de tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5036;
--
-- AUTO_INCREMENT de tabela `agendas`
--
ALTER TABLE `agendas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1598;
--
-- AUTO_INCREMENT de tabela `agendas_cirurgias`
--
ALTER TABLE `agendas_cirurgias`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT de tabela `agendas_consultas`
--
ALTER TABLE `agendas_consultas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=116;
--
-- AUTO_INCREMENT de tabela `agendas_diversos`
--
ALTER TABLE `agendas_diversos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT de tabela `agendas_esteticas`
--
ALTER TABLE `agendas_esteticas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=355;
--
-- AUTO_INCREMENT de tabela `agendas_esteticas_comandas`
--
ALTER TABLE `agendas_esteticas_comandas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=189;
--
-- AUTO_INCREMENT de tabela `agendas_exame_bioquimicos`
--
ALTER TABLE `agendas_exame_bioquimicos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de tabela `agendas_exame_cavitarios`
--
ALTER TABLE `agendas_exame_cavitarios`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de tabela `agendas_exame_citologias`
--
ALTER TABLE `agendas_exame_citologias`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `agendas_exame_dermatologicos`
--
ALTER TABLE `agendas_exame_dermatologicos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de tabela `agendas_exame_eletros`
--
ALTER TABLE `agendas_exame_eletros`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de tabela `agendas_exame_fezes`
--
ALTER TABLE `agendas_exame_fezes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT de tabela `agendas_exame_hemogramas`
--
ALTER TABLE `agendas_exame_hemogramas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de tabela `agendas_exame_outros`
--
ALTER TABLE `agendas_exame_outros`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `agendas_exame_sorologias`
--
ALTER TABLE `agendas_exame_sorologias`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de tabela `agendas_exame_ultrasons`
--
ALTER TABLE `agendas_exame_ultrasons`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `agendas_exame_urinas`
--
ALTER TABLE `agendas_exame_urinas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de tabela `agendas_hospedagens`
--
ALTER TABLE `agendas_hospedagens`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de tabela `agendas_internacoes`
--
ALTER TABLE `agendas_internacoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT de tabela `agendas_obs`
--
ALTER TABLE `agendas_obs`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT de tabela `agendas_repeticoes`
--
ALTER TABLE `agendas_repeticoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2993;
--
-- AUTO_INCREMENT de tabela `agendas_terapeuticas`
--
ALTER TABLE `agendas_terapeuticas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT de tabela `agendas_vacinas`
--
ALTER TABLE `agendas_vacinas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT de tabela `agressividades`
--
ALTER TABLE `agressividades`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de tabela `aliquotas`
--
ALTER TABLE `aliquotas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de tabela `animais`
--
ALTER TABLE `animais`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT de tabela `bairros`
--
ALTER TABLE `bairros`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `bancos`
--
ALTER TABLE `bancos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT de tabela `bancos_tipos_contas`
--
ALTER TABLE `bancos_tipos_contas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `bandeiras`
--
ALTER TABLE `bandeiras`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1001;
--
-- AUTO_INCREMENT de tabela `caixa_fechamentos`
--
ALTER TABLE `caixa_fechamentos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT de tabela `cartas`
--
ALTER TABLE `cartas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `centros_custos`
--
ALTER TABLE `centros_custos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de tabela `centros_custos_subs`
--
ALTER TABLE `centros_custos_subs`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de tabela `clinicas`
--
ALTER TABLE `clinicas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `comandas_grupos`
--
ALTER TABLE `comandas_grupos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `comandas_itens`
--
ALTER TABLE `comandas_itens`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de tabela `comissoes`
--
ALTER TABLE `comissoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7188;
--
-- AUTO_INCREMENT de tabela `comissoes_tipos`
--
ALTER TABLE `comissoes_tipos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `contas`
--
ALTER TABLE `contas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `contas_extratos`
--
ALTER TABLE `contas_extratos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `conversao`
--
ALTER TABLE `conversao`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=534;
--
-- AUTO_INCREMENT de tabela `cores`
--
ALTER TABLE `cores`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de tabela `creditos_obs`
--
ALTER TABLE `creditos_obs`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de tabela `dividas`
--
ALTER TABLE `dividas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `dompdf`
--
ALTER TABLE `dompdf`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT de tabela `emails`
--
ALTER TABLE `emails`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT de tabela `embalagens`
--
ALTER TABLE `embalagens`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT de tabela `entradas_saidas`
--
ALTER TABLE `entradas_saidas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `especies`
--
ALTER TABLE `especies`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1033;
--
-- AUTO_INCREMENT de tabela `estoques`
--
ALTER TABLE `estoques`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de tabela `exames`
--
ALTER TABLE `exames`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `exames_bioquimicos`
--
ALTER TABLE `exames_bioquimicos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `exames_hemogramas`
--
ALTER TABLE `exames_hemogramas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `exames_interpretacoes`
--
ALTER TABLE `exames_interpretacoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=538;
--
-- AUTO_INCREMENT de tabela `exames_tipos`
--
ALTER TABLE `exames_tipos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de tabela `faturas`
--
ALTER TABLE `faturas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1239;
--
-- AUTO_INCREMENT de tabela `feriados`
--
ALTER TABLE `feriados`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de tabela `financeiros`
--
ALTER TABLE `financeiros`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36977;
--
-- AUTO_INCREMENT de tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de tabela `fotos`
--
ALTER TABLE `fotos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1372;
--
-- AUTO_INCREMENT de tabela `graficos`
--
ALTER TABLE `graficos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT de tabela `grupos`
--
ALTER TABLE `grupos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT de tabela `janelas_permissoes`
--
ALTER TABLE `janelas_permissoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `laboratorios`
--
ALTER TABLE `laboratorios`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de tabela `log`
--
ALTER TABLE `log`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=923;
--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `lojas`
--
ALTER TABLE `lojas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `marcas`
--
ALTER TABLE `marcas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de tabela `orgaos`
--
ALTER TABLE `orgaos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=808;
--
-- AUTO_INCREMENT de tabela `pagamentos_bandeiras`
--
ALTER TABLE `pagamentos_bandeiras`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=100;
--
-- AUTO_INCREMENT de tabela `pagamentos_formas`
--
ALTER TABLE `pagamentos_formas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1003;
--
-- AUTO_INCREMENT de tabela `patologias`
--
ALTER TABLE `patologias`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de tabela `pelagens`
--
ALTER TABLE `pelagens`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=183;
--
-- AUTO_INCREMENT de tabela `pelos`
--
ALTER TABLE `pelos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de tabela `portes`
--
ALTER TABLE `portes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de tabela `principios_ativos`
--
ALTER TABLE `principios_ativos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=472;
--
-- AUTO_INCREMENT de tabela `principios_ativos_interacoes`
--
ALTER TABLE `principios_ativos_interacoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `proprietarios`
--
ALTER TABLE `proprietarios`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=147;
--
-- AUTO_INCREMENT de tabela `proprietarios_apaga`
--
ALTER TABLE `proprietarios_apaga`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `racas`
--
ALTER TABLE `racas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=162;
--
-- AUTO_INCREMENT de tabela `relatorios_categorias_old`
--
ALTER TABLE `relatorios_categorias_old`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de tabela `relatorios_old`
--
ALTER TABLE `relatorios_old`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT de tabela `servicos`
--
ALTER TABLE `servicos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT de tabela `servicos_detalhes`
--
ALTER TABLE `servicos_detalhes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT de tabela `servicos_estoques`
--
ALTER TABLE `servicos_estoques`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de tabela `sessoes`
--
ALTER TABLE `sessoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20161;
--
-- AUTO_INCREMENT de tabela `sintomas`
--
ALTER TABLE `sintomas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `sintomas_patologias`
--
ALTER TABLE `sintomas_patologias`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `sistemas`
--
ALTER TABLE `sistemas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10001;
--
-- AUTO_INCREMENT de tabela `situacoes_tributarias`
--
ALTER TABLE `situacoes_tributarias`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de tabela `tamanhos`
--
ALTER TABLE `tamanhos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `taxas`
--
ALTER TABLE `taxas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de tabela `taxas_descricoes`
--
ALTER TABLE `taxas_descricoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1760;
--
-- AUTO_INCREMENT de tabela `taxas_detalhes`
--
ALTER TABLE `taxas_detalhes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=301;
--
-- AUTO_INCREMENT de tabela `unidades`
--
ALTER TABLE `unidades`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=126;
--
-- AUTO_INCREMENT de tabela `usuarios_cargos`
--
ALTER TABLE `usuarios_cargos`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de tabela `usuarios_permissoes`
--
ALTER TABLE `usuarios_permissoes`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT de tabela `valores`
--
ALTER TABLE `valores`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=232;
--
-- AUTO_INCREMENT de tabela `variaveis`
--
ALTER TABLE `variaveis`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22699;
--
-- AUTO_INCREMENT de tabela `vendas`
--
ALTER TABLE `vendas`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1463;
--
-- AUTO_INCREMENT de tabela `vias_administracao`
--
ALTER TABLE `vias_administracao`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT de tabela `xmls`
--
ALTER TABLE `xmls`
  MODIFY `cod_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
